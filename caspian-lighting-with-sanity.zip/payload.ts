// This is a mock implementation of the Payload client for the preview environment
const payload = {
  find: async ({ collection, where, sort, page, limit, depth }: any) => {
    // Return mock data based on the collection
    switch (collection) {
      case "products":
        return mockProductsResponse(limit)
      case "categories":
        return mockCategoriesResponse()
      case "projects":
        return mockProjectsResponse(limit)
      case "blog-posts":
        return mockBlogPostsResponse(limit)
      case "blog-categories":
        return mockBlogCategoriesResponse()
      case "project-categories":
        return mockProjectCategoriesResponse()
      case "testimonials":
        return mockTestimonialsResponse(limit)
      case "pages":
        return mockPagesResponse()
      default:
        return { docs: [], totalDocs: 0, totalPages: 1, page: 1 }
    }
  },
  findGlobal: async ({ slug }: { slug: string }) => {
    // Return mock global data
    switch (slug) {
      case "navigation":
        return mockNavigation()
      case "footer":
        return mockFooter()
      case "social-media":
        return mockSocialMedia()
      case "site-settings":
        return mockSiteSettings()
      default:
        return null
    }
  },
  create: async ({ collection, data }: any) => {
    // Mock creating a document
    console.log(`Mock creating document in ${collection}:`, data)
    return { id: "mock-id", ...data }
  },
}

// Mock data functions
function mockProductsResponse(limit = 10) {
  const products = Array.from({ length: limit }, (_, i) => ({
    id: `product-${i + 1}`,
    title: `Product ${i + 1}`,
    slug: `product-${i + 1}`,
    description: "A premium lighting product for your home or office.",
    price: 99.99 + i * 10,
    compareAtPrice: i % 3 === 0 ? 129.99 + i * 10 : null,
    sku: `SKU-${1000 + i}`,
    inStock: i % 5 !== 0,
    featured: i % 4 === 0,
    category: {
      id: `category-${(i % 4) + 1}`,
      title: ["Chandeliers", "Wall Lights", "Spotlights", "Outdoor Lights"][i % 4],
      slug: ["chandeliers", "wall-lights", "spotlights", "outdoor-lights"][i % 4],
    },
    images: [
      {
        image: {
          url: `/placeholder.svg?height=600&width=600&text=Product+${i + 1}`,
          alt: `Product ${i + 1}`,
          width: 600,
          height: 600,
        },
        alt: `Product ${i + 1}`,
      },
    ],
    content: [
      {
        children: [
          {
            text: `Detailed description for Product ${i + 1}. This premium lighting solution is designed to enhance any space with its elegant design and superior illumination.`,
          },
        ],
      },
    ],
    specifications: {
      dimensions: "30cm x 30cm x 40cm",
      weight: "2.5kg",
      material: "Metal and Glass",
      bulbType: "LED",
      wattage: "15W",
      voltage: "110-240V",
      colorTemperature: "3000K",
      ipRating: "IP20",
    },
  }))

  return {
    docs: products,
    totalDocs: 50,
    totalPages: 5,
    page: 1,
  }
}

function mockCategoriesResponse() {
  return {
    docs: [
      { id: "category-1", title: "Chandeliers", slug: "chandeliers" },
      { id: "category-2", title: "Wall Lights", slug: "wall-lights" },
      { id: "category-3", title: "Spotlights", slug: "spotlights" },
      { id: "category-4", title: "Outdoor Lights", slug: "outdoor-lights" },
    ],
    totalDocs: 4,
    totalPages: 1,
    page: 1,
  }
}

function mockProjectsResponse(limit = 10) {
  const projects = Array.from({ length: limit }, (_, i) => ({
    id: `project-${i + 1}`,
    title: `Project ${i + 1}`,
    slug: `project-${i + 1}`,
    description: "A showcase of our lighting solutions in a real-world setting.",
    completedAt: new Date().toISOString(),
    category: {
      id: `project-category-${(i % 3) + 1}`,
      title: ["Hotels", "Government Buildings", "Residential"][i % 3],
      slug: ["hotels", "government-buildings", "residential"][i % 3],
    },
    images: [
      {
        image: {
          url: `/placeholder.svg?height=800&width=1200&text=Project+${i + 1}`,
          alt: `Project ${i + 1}`,
          width: 1200,
          height: 800,
        },
        alt: `Project ${i + 1}`,
      },
    ],
    content: [
      {
        children: [
          {
            text: `Detailed description for Project ${i + 1}. This project showcases our lighting solutions in a ${
              ["luxury hotel", "government building", "high-end residence"][i % 3]
            } setting.`,
          },
        ],
      },
    ],
  }))

  return {
    docs: projects,
    totalDocs: 30,
    totalPages: 3,
    page: 1,
  }
}

function mockBlogPostsResponse(limit = 10) {
  const posts = Array.from({ length: limit }, (_, i) => ({
    id: `post-${i + 1}`,
    title: `Blog Post ${i + 1}`,
    slug: `blog-post-${i + 1}`,
    excerpt: "A short excerpt from this informative blog post about lighting design.",
    publishedAt: new Date().toISOString(),
    status: "published",
    author: {
      name: `Author ${(i % 3) + 1}`,
      image: {
        url: `/placeholder.svg?height=100&width=100&text=A${(i % 3) + 1}`,
      },
    },
    categories: [
      {
        id: `blog-category-${(i % 4) + 1}`,
        title: ["Design Tips", "Lighting Trends", "Project Insights", "Industry News"][i % 4],
        slug: ["design-tips", "lighting-trends", "project-insights", "industry-news"][i % 4],
      },
    ],
    coverImage: {
      url: `/placeholder.svg?height=630&width=1200&text=Blog+Post+${i + 1}`,
      alt: `Blog Post ${i + 1}`,
      width: 1200,
      height: 630,
    },
    content: [
      {
        children: [
          {
            text: `Detailed content for Blog Post ${i + 1}. This post discusses important aspects of lighting design and provides valuable insights for readers.`,
          },
        ],
      },
    ],
  }))

  return {
    docs: posts,
    totalDocs: 25,
    totalPages: 3,
    page: 1,
  }
}

function mockBlogCategoriesResponse() {
  return {
    docs: [
      { id: "blog-category-1", title: "Design Tips", slug: "design-tips" },
      { id: "blog-category-2", title: "Lighting Trends", slug: "lighting-trends" },
      { id: "blog-category-3", title: "Project Insights", slug: "project-insights" },
      { id: "blog-category-4", title: "Industry News", slug: "industry-news" },
    ],
    totalDocs: 4,
    totalPages: 1,
    page: 1,
  }
}

function mockProjectCategoriesResponse() {
  return {
    docs: [
      { id: "project-category-1", title: "Hotels", slug: "hotels" },
      { id: "project-category-2", title: "Government Buildings", slug: "government-buildings" },
      { id: "project-category-3", title: "Residential", slug: "residential" },
    ],
    totalDocs: 3,
    totalPages: 1,
    page: 1,
  }
}

function mockTestimonialsResponse(limit = 3) {
  return {
    docs: Array.from({ length: limit }, (_, i) => ({
      id: `testimonial-${i + 1}`,
      name: `Client ${i + 1}`,
      position: ["Interior Designer", "Project Manager", "Property Manager"][i % 3],
      company: ["Grand Plaza Hotel", "Urban Development Corp", "Seaside Residences"][i % 3],
      content: `"The ${
        i % 2 === 0 ? "chandeliers" : "lighting solutions"
      } from Caspian Lighting transformed our space. The quality and craftsmanship are exceptional, and their team provided outstanding support throughout the project."`,
      image: {
        url: `/placeholder.svg?height=100&width=100&text=C${i + 1}`,
      },
    })),
    totalDocs: 10,
    totalPages: 4,
    page: 1,
  }
}

function mockPagesResponse() {
  return {
    docs: [
      {
        id: "page-1",
        title: "Home",
        slug: "home",
        hero: {
          title: "Light Up Your World with Elegance",
          subtitle: "Premium lighting solutions for homes, offices, and design projects",
          backgroundImage: {
            url: "/placeholder.svg?height=1080&width=1920",
          },
          ctaText: "Explore Collections",
          ctaLink: "/products",
        },
        productSection: {
          title: "Illuminate Every Space",
          subtitle: "Discover our premium lighting solutions for every room and purpose",
        },
        whyChooseSection: {
          title: "Why Choose Caspian Lighting?",
          subtitle: "We combine quality, customization, and reliability to deliver exceptional lighting solutions",
          features: [
            {
              title: "Certified Quality",
              description: "All our products meet international quality standards and come with extended warranties",
              icon: "Award",
            },
            {
              title: "Project-Based Customization",
              description:
                "Our team works with you to create custom lighting solutions tailored to your specific needs",
              icon: "Clock",
            },
            {
              title: "Fast Delivery",
              description: "Quick and reliable delivery service with professional installation options available",
              icon: "Truck",
            },
          ],
        },
        projectsSection: {
          title: "Projects Showcase",
          subtitle: "Explore our completed projects in luxury hotels, government buildings, and high-end residences",
        },
        designerSection: {
          title: "Designer Corner",
          description:
            "Are you an interior designer looking to collaborate? Join our network of professionals and showcase your projects featuring Caspian Lighting products.",
          ctaText: "Join Designer Network",
          ctaLink: "/designer-network",
          image: {
            url: "/placeholder.svg?height=600&width=600",
          },
        },
        testimonialsSection: {
          title: "What Our Clients Say",
          subtitle: "Hear from our satisfied customers about their experience with Caspian Lighting",
        },
        newsletterSection: {
          title: "Stay Updated with Caspian Lighting",
          subtitle:
            "Subscribe to our newsletter for the latest product updates, design inspiration, and exclusive offers",
        },
      },
      {
        id: "page-2",
        title: "About",
        slug: "about",
        content: [
          {
            children: [
              {
                text: "About Caspian Lighting - we are a premium lighting solutions provider with over 15 years of experience in the industry.",
              },
            ],
          },
        ],
      },
      {
        id: "page-3",
        title: "Contact",
        slug: "contact",
        content: [
          {
            children: [
              {
                text: "Contact Caspian Lighting for inquiries, quotes, or support. We'd love to hear from you!",
              },
            ],
          },
        ],
      },
    ],
    totalDocs: 3,
    totalPages: 1,
    page: 1,
  }
}

function mockNavigation() {
  return {
    items: [
      { title: "Home", href: "/" },
      { title: "Products", href: "/products" },
      { title: "Projects", href: "/projects" },
      { title: "Blog", href: "/blog" },
      { title: "About", href: "/about" },
      { title: "Contact", href: "/contact" },
    ],
  }
}

function mockFooter() {
  return {
    links: [
      {
        title: "Collections",
        links: [
          { label: "Chandeliers", url: "/products/categories/chandeliers" },
          { label: "Wall Lights", url: "/products/categories/wall-lights" },
          { label: "Spotlights", url: "/products/categories/spotlights" },
          { label: "Outdoor Lights", url: "/products/categories/outdoor-lights" },
          { label: "Smart Lighting", url: "/products/categories/smart-lighting" },
        ],
      },
      {
        title: "Company",
        links: [
          { label: "About Us", url: "/about" },
          { label: "Projects", url: "/projects" },
          { label: "Blog", url: "/blog" },
          { label: "Careers", url: "/careers" },
          { label: "Contact", url: "/contact" },
        ],
      },
    ],
    contactInfo: {
      address: "123 Lighting Avenue, Baku, Azerbaijan",
      phone: "+994 12 345 6789",
      email: "info@caspianlighting.az",
      openingHours: "Opening Hours: Mon-Fri 9:00 - 18:00",
    },
    copyright: "© 2023 Caspian Lighting. All rights reserved.",
  }
}

function mockSocialMedia() {
  return {
    links: [
      { platform: "Facebook", url: "https://facebook.com" },
      { platform: "Instagram", url: "https://instagram.com" },
      { platform: "Twitter", url: "https://twitter.com" },
    ],
  }
}

function mockSiteSettings() {
  return {
    siteName: "Caspian Lighting",
    siteDescription: "Premium lighting solutions for homes, offices, and design projects",
    contactEmail: "info@caspianlighting.az",
    contactPhone: "+994 12 345 6789",
  }
}

export default payload
