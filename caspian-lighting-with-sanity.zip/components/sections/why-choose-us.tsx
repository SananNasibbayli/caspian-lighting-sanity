import type React from "react"
import { Award, Clock, Truck } from "lucide-react"

type Feature = {
  title: string
  description: string
  icon: string
}

type WhyChooseUsProps = {
  title: string
  subtitle: string
  features: Feature[]
}

export default function WhyChooseUs({ title, subtitle, features }: WhyChooseUsProps) {
  // Map of icon names to components
  const iconMap: Record<string, React.ReactNode> = {
    Award: <Award className="h-8 w-8 text-amber-600" />,
    Clock: <Clock className="h-8 w-8 text-amber-600" />,
    Truck: <Truck className="h-8 w-8 text-amber-600" />,
  }

  return (
    <section className="w-full bg-amber-50 py-12 md:py-24 lg:py-32">
      <div className="container space-y-12 px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <div className="inline-block rounded-lg bg-amber-100 px-3 py-1 text-sm text-amber-800">Our Advantages</div>
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">{title}</h2>
            <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              {subtitle}
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
          {features.map((feature, index) => (
            <div
              key={index}
              className="flex flex-col items-center space-y-4 rounded-lg border bg-white p-6 shadow-sm transition-all hover:shadow-md"
            >
              <div className="rounded-full bg-amber-100 p-4">
                {iconMap[feature.icon] || <Award className="h-8 w-8 text-amber-600" />}
              </div>
              <h3 className="text-xl font-bold">{feature.title}</h3>
              <p className="text-center text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
