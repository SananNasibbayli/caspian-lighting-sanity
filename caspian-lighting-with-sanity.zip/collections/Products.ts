import type { CollectionConfig } from "payload/types"
import { isAdmin } from "../access/isAdmin"
import { isAdminOrHasAccess } from "../access/isAdminOrHasAccess"
import formatSlug from "../utilities/formatSlug"

const Products: CollectionConfig = {
  slug: "products",
  admin: {
    useAsTitle: "title",
    defaultColumns: ["title", "category", "price", "inStock", "updatedAt"],
    group: "Shop",
  },
  access: {
    read: () => true,
    create: isAdmin,
    update: isAdminOrHasAccess,
    delete: isAdmin,
  },
  fields: [
    {
      name: "title",
      type: "text",
      required: true,
    },
    {
      name: "slug",
      type: "text",
      admin: {
        position: "sidebar",
      },
      hooks: {
        beforeValidate: [formatSlug("title")],
      },
    },
    {
      name: "description",
      type: "textarea",
      required: true,
    },
    {
      name: "price",
      type: "number",
      required: true,
      min: 0,
    },
    {
      name: "compareAtPrice",
      label: "Compare at Price",
      type: "number",
      min: 0,
      admin: {
        description: "Original price before discount",
      },
    },
    {
      name: "sku",
      label: "SKU",
      type: "text",
      required: true,
      admin: {
        description: "Stock Keeping Unit",
      },
    },
    {
      name: "inStock",
      type: "checkbox",
      defaultValue: true,
      admin: {
        position: "sidebar",
        description: "Is this product in stock?",
      },
    },
    {
      name: "featured",
      type: "checkbox",
      defaultValue: false,
      admin: {
        position: "sidebar",
        description: "Should this product be featured on the homepage?",
      },
    },
    {
      name: "category",
      type: "relationship",
      relationTo: "categories",
      required: true,
      admin: {
        position: "sidebar",
      },
    },
    {
      name: "images",
      type: "array",
      required: true,
      minRows: 1,
      admin: {
        description: "Upload at least one image",
      },
      fields: [
        {
          name: "image",
          type: "upload",
          relationTo: "media",
          required: true,
        },
        {
          name: "alt",
          type: "text",
          required: true,
          admin: {
            description: "Describe this image for screen readers",
          },
        },
      ],
    },
    {
      name: "content",
      type: "richText",
      admin: {
        description: "Detailed product description",
      },
    },
    {
      name: "specifications",
      type: "group",
      admin: {
        description: "Technical specifications",
      },
      fields: [
        {
          name: "dimensions",
          type: "text",
          admin: {
            description: "e.g. 10cm x 20cm x 30cm",
          },
        },
        {
          name: "weight",
          type: "text",
        },
        {
          name: "material",
          type: "text",
        },
        {
          name: "bulbType",
          label: "Bulb Type",
          type: "text",
        },
        {
          name: "wattage",
          type: "text",
        },
        {
          name: "voltage",
          type: "text",
        },
        {
          name: "colorTemperature",
          label: "Color Temperature",
          type: "text",
        },
        {
          name: "ipRating",
          label: "IP Rating",
          type: "text",
        },
        {
          name: "customSpecifications",
          type: "array",
          fields: [
            {
              name: "name",
              type: "text",
              required: true,
            },
            {
              name: "value",
              type: "text",
              required: true,
            },
          ],
        },
      ],
    },
    {
      name: "relatedProducts",
      type: "relationship",
      relationTo: "products",
      hasMany: true,
      admin: {
        description: "Select related products to display",
      },
    },
    {
      name: "metaTitle",
      type: "text",
      admin: {
        description: "Custom meta title for SEO (defaults to product title if empty)",
      },
    },
    {
      name: "metaDescription",
      type: "textarea",
      admin: {
        description: "Custom meta description for SEO (defaults to product description if empty)",
      },
    },
  ],
  hooks: {
    afterChange: [
      async ({ doc }) => {
        // Instead of directly calling revalidate from here (which exposes env vars to client),
        // we'll just log that a product was changed
        console.log(`Product ${doc.title} (${doc.slug}) was updated.`)

        // In a production environment, you would implement a secure revalidation strategy
        // such as using a webhook or a server-side cron job
      },
    ],
  },
}

export default Products
