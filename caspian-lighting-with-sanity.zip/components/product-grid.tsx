import Link from "next/link"
import Image from "next/image"
import { formatPrice } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"
import AddToCartButton from "@/components/add-to-cart-button"

export default function ProductGrid({ products }: { products: any[] }) {
  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {products.map((product) => (
        <div
          key={product.id}
          className="group relative flex flex-col overflow-hidden rounded-lg border bg-white shadow-sm transition-all hover:shadow-md"
        >
          {/* Product Badge */}
          {product.compareAtPrice && product.compareAtPrice > product.price && (
            <Badge className="absolute left-4 top-4 z-10 bg-amber-600 hover:bg-amber-700">Sale</Badge>
          )}

          {/* Product Image */}
          <Link href={`/products/${product.slug}`} className="aspect-square overflow-hidden bg-gray-100">
            <Image
              src={product.images?.[0]?.image?.url || "/placeholder.svg?height=600&width=600"}
              alt={product.images?.[0]?.alt || product.title}
              width={600}
              height={600}
              className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
          </Link>

          {/* Product Details */}
          <div className="flex flex-1 flex-col p-4">
            <Link
              href={`/products/categories/${product.category.slug}`}
              className="mb-1 text-xs text-muted-foreground hover:text-amber-600"
            >
              {product.category.title}
            </Link>

            <Link href={`/products/${product.slug}`} className="flex-1">
              <h3 className="line-clamp-2 font-medium hover:text-amber-600">{product.title}</h3>
            </Link>

            <div className="mt-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="font-medium text-amber-600">{formatPrice(product.price)}</span>

                {product.compareAtPrice && product.compareAtPrice > product.price && (
                  <span className="text-sm text-muted-foreground line-through">
                    {formatPrice(product.compareAtPrice)}
                  </span>
                )}
              </div>

              {!product.inStock ? <span className="text-xs text-red-600">Out of stock</span> : null}
            </div>

            <div className="mt-4">
              <AddToCartButton product={product} variant="outline" />
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
