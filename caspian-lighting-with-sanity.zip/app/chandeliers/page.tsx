import ChandeliersPage from "./index-page"

export default ChandeliersPage

export const metadata = {
  title: "Chandeliers | Caspian Lighting",
  description: "Explore our collection of elegant chandeliers for your home or commercial space",
}
