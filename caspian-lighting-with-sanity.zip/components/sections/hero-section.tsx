import Link from "next/link"
import Image from "next/image"
import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

type HeroSectionProps = {
  title: string
  subtitle: string
  backgroundImage: string
  ctaText: string
  ctaLink: string
}

export default function HeroSection({ title, subtitle, backgroundImage, ctaText, ctaLink }: HeroSectionProps) {
  return (
    <section className="relative h-[80vh] w-full overflow-hidden">
      <Image
        src={backgroundImage || "/placeholder.svg"}
        alt={title}
        fill
        className="object-cover brightness-75"
        priority
      />
      <div className="absolute inset-0 bg-gradient-to-r from-black/50 to-transparent">
        <div className="container relative flex h-full flex-col items-start justify-center gap-4 pt-16">
          <div className="animate-fade-in-up space-y-4 max-w-xl">
            <h1 className="text-4xl font-bold tracking-tighter text-white sm:text-5xl md:text-6xl lg:text-7xl">
              {title}
            </h1>
            <p className="text-xl text-white/90 md:text-2xl">{subtitle}</p>
            <div className="flex flex-col gap-4 sm:flex-row">
              <Button size="lg" className="bg-amber-600 hover:bg-amber-700">
                <Link href={ctaLink} className="flex items-center">
                  {ctaText} <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/20">
                View Projects
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
