import { getProjects } from "@/lib/payload-utils"
import { getProjectCategories } from "@/lib/payload-utils"
import ProjectCard from "@/components/project-card"
import ProjectCategoriesFilter from "@/components/project-categories-filter"
import { Pagination } from "@/components/pagination"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export const metadata = {
  title: "Projects | Caspian Lighting",
  description:
    "Explore our completed lighting projects in luxury hotels, government buildings, and high-end residences",
}

export default async function ProjectsPage({
  searchParams,
}: {
  searchParams: { [key: string]: string | string[] | undefined }
}) {
  // Get query parameters
  const page = typeof searchParams.page === "string" ? Number.parseInt(searchParams.page) : 1
  const limit = 9
  const category = typeof searchParams.category === "string" ? searchParams.category : undefined

  // Fetch projects and categories
  const { projects, totalProjects, totalPages } = await getProjects({
    page,
    limit,
    category,
    depth: 2,
  })

  const categories = await getProjectCategories()

  // Featured project (first project or mock data if none)
  const featuredProject = projects[0] || {
    title: "Luxury Hotel Lighting Installation",
    description:
      "Complete lighting solution for a 5-star hotel in Baku, featuring custom chandeliers and smart lighting integration.",
    slug: "luxury-hotel-project",
    category: { title: "Hotels", slug: "hotels" },
    images: [{ image: { url: "/placeholder.svg?height=600&width=1200&text=Featured+Project" } }],
  }

  return (
    <div className="container py-12 md:py-16">
      {/* Hero Section */}
      <div className="mb-16 text-center">
        <h1 className="text-3xl font-bold md:text-4xl">Our Projects</h1>
        <p className="mt-4 max-w-3xl mx-auto text-muted-foreground">
          Explore our portfolio of completed lighting projects across luxury hotels, government buildings, high-end
          residences, and commercial spaces. Each project showcases our commitment to quality, innovation, and
          exceptional lighting design.
        </p>
      </div>

      {/* Featured Project */}
      <div className="mb-20">
        <h2 className="text-2xl font-bold mb-8">Featured Project</h2>
        <div className="grid md:grid-cols-2 gap-8 items-center bg-amber-50 rounded-lg overflow-hidden">
          <div className="h-[400px] relative">
            <img
              src={featuredProject.images?.[0]?.image?.url || "/placeholder.svg?height=400&width=600"}
              alt={featuredProject.title}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="p-8">
            <div className="inline-block rounded-full bg-amber-100 px-3 py-1 text-sm text-amber-800 mb-4">
              {featuredProject.category?.title || "Featured"}
            </div>
            <h3 className="text-2xl font-bold mb-4">{featuredProject.title}</h3>
            <p className="mb-6 text-muted-foreground">{featuredProject.description}</p>
            <Button className="bg-amber-600 hover:bg-amber-700">
              <a href={`/projects/${featuredProject.slug}`} className="flex items-center">
                View Project <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
          </div>
        </div>
      </div>

      {/* Project Categories */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-6">Browse Projects by Category</h2>
        <ProjectCategoriesFilter categories={categories} selectedCategory={category} />
      </div>

      {/* Projects Grid */}
      {projects.length > 0 ? (
        <>
          <div className="mt-8 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {projects.map((project) => (
              <ProjectCard key={project.id} project={project} />
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="mt-12 flex justify-center">
              <Pagination totalPages={totalPages} currentPage={page} />
            </div>
          )}
        </>
      ) : (
        <div className="flex h-[400px] items-center justify-center rounded-md border border-dashed">
          <div className="text-center">
            <h3 className="text-lg font-medium">No projects found</h3>
            <p className="mt-1 text-sm text-muted-foreground">Check back soon for new projects.</p>
          </div>
        </div>
      )}

      {/* Project Process */}
      <div className="mt-20">
        <h2 className="text-2xl font-bold mb-8 text-center">Our Project Process</h2>
        <div className="grid md:grid-cols-4 gap-6">
          {[
            {
              step: "1",
              title: "Consultation",
              description: "We begin with a thorough consultation to understand your vision, requirements, and budget.",
            },
            {
              step: "2",
              title: "Design",
              description: "Our design team creates a comprehensive lighting plan tailored to your space and needs.",
            },
            {
              step: "3",
              title: "Installation",
              description: "Our expert technicians handle the installation with precision and care.",
            },
            {
              step: "4",
              title: "Support",
              description:
                "We provide ongoing support and maintenance to ensure your lighting continues to perform perfectly.",
            },
          ].map((item, index) => (
            <div key={index} className="border rounded-lg p-6 text-center">
              <div className="w-10 h-10 rounded-full bg-amber-600 text-white flex items-center justify-center mx-auto mb-4">
                {item.step}
              </div>
              <h3 className="text-lg font-bold mb-2">{item.title}</h3>
              <p className="text-muted-foreground">{item.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Testimonials */}
      <div className="mt-20 bg-amber-50 rounded-lg p-8">
        <h2 className="text-2xl font-bold mb-8 text-center">What Our Clients Say</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              quote:
                "Caspian Lighting transformed our hotel lobby with their stunning chandeliers. The attention to detail and quality of work was exceptional.",
              name: "Farid Mammadov",
              position: "General Manager, Grand Plaza Hotel",
            },
            {
              quote:
                "Working with Caspian Lighting on our office redesign was a pleasure. Their team understood our needs and delivered a lighting solution that enhances productivity and aesthetics.",
              name: "Leyla Aliyeva",
              position: "Facilities Director, AzTech Industries",
            },
            {
              quote:
                "The outdoor lighting system designed for our residence has completely transformed our garden. We're impressed with both the design and the quality of the fixtures.",
              name: "Eldar Hasanov",
              position: "Homeowner",
            },
          ].map((testimonial, index) => (
            <div key={index} className="bg-white rounded-lg p-6 shadow-sm">
              <p className="italic mb-4">"{testimonial.quote}"</p>
              <div>
                <p className="font-bold">{testimonial.name}</p>
                <p className="text-sm text-muted-foreground">{testimonial.position}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="mt-20 text-center">
        <h2 className="text-2xl font-bold mb-4">Ready to Start Your Project?</h2>
        <p className="max-w-2xl mx-auto mb-8 text-muted-foreground">
          Whether you're planning a residential renovation, commercial development, or hospitality project, our team is
          ready to create the perfect lighting solution for your space.
        </p>
        <Button size="lg" className="bg-amber-600 hover:bg-amber-700">
          <a href="/contact">Contact Our Project Team</a>
        </Button>
      </div>
    </div>
  )
}
