"use client"

import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { Card, CardContent } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

type ProductSpecsChartProps = {
  specifications: [string, any][]
}

export default function ProductSpecsChart({ specifications }: ProductSpecsChartProps) {
  // Filter specifications that can be represented numerically
  const numericSpecs = specifications.filter(([_, value]) => {
    const numValue = Number.parseFloat(value)
    return !isNaN(numValue) && typeof numValue === "number"
  })

  // If no numeric specs, show a message
  if (numericSpecs.length === 0) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-center text-muted-foreground">No chart data available for this product</p>
        </CardContent>
      </Card>
    )
  }

  // Prepare data for the chart
  const chartData = numericSpecs.map(([name, value]) => {
    // Extract numeric value (remove units)
    const numValue = Number.parseFloat(value)
    return {
      name: name,
      value: numValue,
    }
  })

  return (
    <Card>
      <CardContent className="p-6">
        <ChartContainer
          config={{
            value: {
              label: "Value",
              color: "hsl(var(--chart-1))",
            },
          }}
          className="h-[300px]"
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" angle={-45} textAnchor="end" height={70} tick={{ fontSize: 12 }} />
              <YAxis />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Legend />
              <Bar dataKey="value" fill="var(--color-value)" name="Value" />
            </BarChart>
          </ResponsiveContainer>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
