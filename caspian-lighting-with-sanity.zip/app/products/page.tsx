import { getProducts } from "@/lib/payload-utils"
import { getCategories } from "@/lib/payload-utils"
import ProductGrid from "@/components/product-grid"
import ProductFilters from "@/components/product-filters"
import { Pagination } from "@/components/pagination"

export const metadata = {
  title: "Products | Caspian Lighting",
  description: "Browse our collection of premium lighting solutions for homes, offices, and design projects",
}

export default async function ProductsPage({
  searchParams,
}: {
  searchParams: { [key: string]: string | string[] | undefined }
}) {
  // Get query parameters
  const page = typeof searchParams.page === "string" ? Number.parseInt(searchParams.page) : 1
  const limit = 12
  const category = typeof searchParams.category === "string" ? searchParams.category : undefined
  const sort = typeof searchParams.sort === "string" ? searchParams.sort : "latest"
  const search = typeof searchParams.search === "string" ? searchParams.search : undefined

  // Fetch products and categories
  const { products, totalProducts, totalPages } = await getProducts({
    page,
    limit,
    category,
    sort,
    search,
    depth: 1,
  })

  const categories = await getCategories()

  return (
    <div className="container py-12 md:py-16">
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold md:text-4xl">Our Products</h1>
        <p className="mt-4 text-muted-foreground">
          Browse our collection of premium lighting solutions for homes, offices, and design projects
        </p>
      </div>

      <div className="grid gap-8 md:grid-cols-[240px_1fr]">
        {/* Filters */}
        <ProductFilters categories={categories} />

        <div>
          {/* Products */}
          {products.length > 0 ? (
            <>
              <div className="mb-8">
                <p className="text-sm text-muted-foreground">
                  Showing {products.length} of {totalProducts} products
                </p>
              </div>

              <ProductGrid products={products} />

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="mt-8 flex justify-center">
                  <Pagination totalPages={totalPages} currentPage={page} />
                </div>
              )}
            </>
          ) : (
            <div className="flex h-[400px] items-center justify-center rounded-md border border-dashed">
              <div className="text-center">
                <h3 className="text-lg font-medium">No products found</h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  Try adjusting your search or filter to find what you're looking for.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
