import Link from "next/link"
import Image from "next/image"
import { format } from "date-fns"

type BlogPostCardProps = {
  post: any
}

export default function BlogPostCard({ post }: BlogPostCardProps) {
  return (
    <div className="group flex flex-col overflow-hidden rounded-lg border bg-white shadow-sm transition-all hover:shadow-md">
      <Link href={`/blog/${post.slug}`} className="aspect-video overflow-hidden bg-gray-100">
        <Image
          src={post.coverImage?.url || "/placeholder.svg?height=300&width=500"}
          alt={post.title}
          width={500}
          height={300}
          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
      </Link>
      <div className="flex flex-1 flex-col p-6">
        <div className="mb-2 flex gap-2">
          {post.categories?.map((category: any) => (
            <Link
              key={category.id}
              href={`/blog/categories/${category.slug}`}
              className="rounded-full bg-amber-100 px-2.5 py-0.5 text-xs text-amber-800 hover:bg-amber-200"
            >
              {category.title}
            </Link>
          ))}
        </div>
        <Link href={`/blog/${post.slug}`} className="flex-1">
          <h3 className="line-clamp-2 text-xl font-bold hover:text-amber-600">{post.title}</h3>
        </Link>
        <p className="mt-2 line-clamp-3 text-muted-foreground">{post.excerpt}</p>
        <div className="mt-4 flex items-center gap-2">
          <div className="h-8 w-8 overflow-hidden rounded-full bg-amber-100">
            {post.author?.image ? (
              <Image
                src={post.author.image.url || "/placeholder.svg"}
                alt={post.author.name}
                width={32}
                height={32}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center text-xs font-medium text-amber-800">
                {post.author?.name?.charAt(0) || "A"}
              </div>
            )}
          </div>
          <div className="flex flex-col">
            <span className="text-xs font-medium">{post.author?.name || "Anonymous"}</span>
            <span className="text-xs text-muted-foreground">
              {post.publishedAt ? format(new Date(post.publishedAt), "MMMM d, yyyy") : "No date"}
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}
