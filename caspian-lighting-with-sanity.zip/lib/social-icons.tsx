import {
  Facebook,
  Instagram,
  Twitter,
  Linkedin,
  Youtube,
  PinIcon as Pinterest,
  Globe,
  type LucideIcon,
} from "lucide-react"

// Map of social media platform names to their corresponding icons
export const socialIcons: Record<string, LucideIcon> = {
  facebook: Facebook,
  instagram: Instagram,
  twitter: Twitter,
  linkedin: Linkedin,
  youtube: Youtube,
  pinterest: Pinterest,
  // Default icon for any platform not explicitly defined
  default: Globe,
}
