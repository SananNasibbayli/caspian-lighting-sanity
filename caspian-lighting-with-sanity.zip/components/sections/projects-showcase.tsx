import Image from "next/image"
import Link from "next/link"
import { ArrowRight, ChevronRight, ChevronLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

type ProjectsShowcaseProps = {
  title: string
  subtitle: string
  projects: any[]
}

export default function ProjectsShowcase({ title, subtitle, projects }: ProjectsShowcaseProps) {
  // Group projects by category
  const projectsByCategory: Record<string, any[]> = {}

  projects.forEach((project) => {
    const categorySlug = project.category?.slug || "other"
    if (!projectsByCategory[categorySlug]) {
      projectsByCategory[categorySlug] = []
    }
    projectsByCategory[categorySlug].push(project)
  })

  // Get unique categories
  const categories = Object.keys(projectsByCategory).map((slug) => {
    const firstProject = projectsByCategory[slug][0]
    return {
      slug,
      title: firstProject.category?.title || "Other",
    }
  })

  return (
    <section className="w-full py-12 md:py-24 lg:py-32">
      <div className="container space-y-12 px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <div className="inline-block rounded-lg bg-amber-100 px-3 py-1 text-sm text-amber-800">Our Portfolio</div>
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">{title}</h2>
            <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              {subtitle}
            </p>
          </div>
        </div>

        <Tabs defaultValue={categories[0]?.slug || "hotels"} className="w-full">
          <div className="flex justify-center">
            <TabsList className="mb-8">
              {categories.map((category) => (
                <TabsTrigger key={category.slug} value={category.slug}>
                  {category.title}
                </TabsTrigger>
              ))}
            </TabsList>
          </div>

          {categories.map((category) => (
            <TabsContent key={category.slug} value={category.slug} className="space-y-4">
              <div className="relative">
                <div className="flex items-center justify-between absolute top-1/2 left-4 right-4 z-10 -translate-y-1/2">
                  <Button size="icon" variant="outline" className="h-8 w-8 rounded-full bg-white/80 backdrop-blur-sm">
                    <ChevronLeft className="h-4 w-4" />
                    <span className="sr-only">Previous slide</span>
                  </Button>
                  <Button size="icon" variant="outline" className="h-8 w-8 rounded-full bg-white/80 backdrop-blur-sm">
                    <ChevronRight className="h-4 w-4" />
                    <span className="sr-only">Next slide</span>
                  </Button>
                </div>
                <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {projectsByCategory[category.slug].slice(0, 3).map((project) => (
                    <Card key={project.id} className="overflow-hidden">
                      <Image
                        src={project.images?.[0]?.image?.url || "/placeholder.svg?height=400&width=600"}
                        alt={project.title}
                        width={600}
                        height={400}
                        className="h-64 w-full object-cover"
                      />
                      <CardContent className="p-4">
                        <h3 className="text-lg font-bold">{project.title}</h3>
                        <p className="text-sm text-muted-foreground">{project.description}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </TabsContent>
          ))}
        </Tabs>

        <div className="flex justify-center">
          <Button className="bg-amber-600 hover:bg-amber-700">
            <Link href="/projects" className="flex items-center">
              View All Projects <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
