import Link from "next/link"
import { Edit, MoreHorizontal, Plus, Trash } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export default function ProductsPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <div className="border-b">
        <div className="flex h-16 items-center px-4">
          <Link href="/admin" className="flex items-center gap-2 font-semibold">
            <span className="text-xl font-bold tracking-tight text-amber-600">Caspian Lighting</span>
            <span className="text-sm text-muted-foreground">Admin</span>
          </Link>
          <nav className="ml-auto flex items-center space-x-4">
            <Link
              href="/"
              className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
            >
              View Site
            </Link>
          </nav>
        </div>
      </div>
      <div className="grid flex-1 md:grid-cols-[220px_1fr]">
        <div className="hidden border-r bg-muted/40 md:block">
          <div className="flex h-full max-h-screen flex-col gap-2">
            <div className="flex-1 overflow-auto py-2">
              <nav className="grid items-start px-2 text-sm font-medium">
                <Link
                  href="/admin"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-foreground"
                >
                  Dashboard
                </Link>
                <Link
                  href="/admin/products"
                  className="flex items-center gap-3 rounded-lg bg-accent px-3 py-2 text-accent-foreground transition-all"
                >
                  Products
                </Link>
                <Link
                  href="#"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-foreground"
                >
                  Orders
                </Link>
                <Link
                  href="#"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-foreground"
                >
                  Customers
                </Link>
                <Link
                  href="#"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-foreground"
                >
                  Projects
                </Link>
                <Link
                  href="#"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-foreground"
                >
                  Settings
                </Link>
              </nav>
            </div>
          </div>
        </div>
        <div className="flex flex-col">
          <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
            <div className="flex items-center justify-between">
              <h1 className="text-lg font-semibold md:text-2xl">Products</h1>
              <div className="flex items-center gap-2">
                <form className="flex items-center gap-2">
                  <Input type="search" placeholder="Search products..." className="h-9 md:w-[300px]" />
                  <Button type="submit" size="sm" variant="ghost">
                    Search
                  </Button>
                </form>
                <Button className="bg-amber-600 hover:bg-amber-700">
                  <Plus className="mr-2 h-4 w-4" /> Add Product
                </Button>
              </div>
            </div>
            <Card>
              <CardHeader>
                <CardTitle>Product Management</CardTitle>
                <CardDescription>Manage your product catalog, update details, and track inventory.</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Product</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Stock</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {[
                      {
                        name: "Crystal Chandelier",
                        category: "Chandeliers",
                        price: "$1,299.99",
                        stock: 15,
                        status: "Active",
                      },
                      {
                        name: "Modern Wall Light",
                        category: "Wall Lights",
                        price: "$249.99",
                        stock: 42,
                        status: "Active",
                      },
                      {
                        name: "Outdoor Spotlight",
                        category: "Outdoor Lights",
                        price: "$189.99",
                        stock: 28,
                        status: "Active",
                      },
                      {
                        name: "Smart LED Strip",
                        category: "Smart Lighting",
                        price: "$79.99",
                        stock: 56,
                        status: "Active",
                      },
                      {
                        name: "Pendant Light",
                        category: "Chandeliers",
                        price: "$349.99",
                        stock: 8,
                        status: "Low Stock",
                      },
                      {
                        name: "Bathroom Sconce",
                        category: "Wall Lights",
                        price: "$129.99",
                        stock: 0,
                        status: "Out of Stock",
                      },
                      {
                        name: "Garden Path Light",
                        category: "Outdoor Lights",
                        price: "$59.99",
                        stock: 32,
                        status: "Active",
                      },
                      {
                        name: "Ceiling Fan with Light",
                        category: "Ceiling Lights",
                        price: "$399.99",
                        stock: 12,
                        status: "Active",
                      },
                    ].map((product, i) => (
                      <TableRow key={i}>
                        <TableCell className="font-medium">{product.name}</TableCell>
                        <TableCell>{product.category}</TableCell>
                        <TableCell>{product.price}</TableCell>
                        <TableCell>{product.stock}</TableCell>
                        <TableCell>
                          <span
                            className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                              product.status === "Active"
                                ? "bg-green-100 text-green-800"
                                : product.status === "Low Stock"
                                  ? "bg-yellow-100 text-yellow-800"
                                  : "bg-red-100 text-red-800"
                            }`}
                          >
                            {product.status}
                          </span>
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">Actions</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem>
                                <Edit className="mr-2 h-4 w-4" /> Edit
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-red-600">
                                <Trash className="mr-2 h-4 w-4" /> Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </main>
        </div>
      </div>
    </div>
  )
}
