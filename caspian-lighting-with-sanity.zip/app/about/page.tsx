import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Award, Users, Lightbulb, Globe } from "lucide-react"

export const metadata = {
  title: "About Us | Caspian Lighting",
  description: "Learn about Caspian Lighting, our history, mission, and values",
}

export default function AboutPage() {
  return (
    <div className="container py-12 md:py-16">
      <div className="mb-12 text-center">
        <h1 className="text-3xl font-bold md:text-4xl">About Caspian Lighting</h1>
        <p className="mt-4 text-muted-foreground">Illuminating spaces with elegance since 2005</p>
      </div>

      {/* Company Overview */}
      <div className="grid gap-12 md:grid-cols-2 items-center mb-20">
        <div>
          <h2 className="text-2xl font-bold mb-4">Our Story</h2>
          <p className="mb-4">
            Founded in 2005, Caspian Lighting has grown from a small family business to one of Azerbaijan's leading
            lighting solution providers. Our journey began with a passion for transforming spaces through thoughtful
            lighting design.
          </p>
          <p className="mb-4">
            Over the years, we've expanded our collection to include thousands of premium lighting products, from
            elegant chandeliers to modern smart lighting solutions. We've had the privilege of illuminating some of the
            most prestigious spaces in the region, including luxury hotels, government buildings, and high-end
            residences.
          </p>
          <p>
            Today, Caspian Lighting continues to be at the forefront of lighting innovation, combining traditional
            craftsmanship with cutting-edge technology to create lighting solutions that inspire and transform.
          </p>
        </div>
        <div className="relative h-[400px] rounded-lg overflow-hidden">
          <Image
            src="/placeholder.svg?height=400&width=600&text=Our+Showroom"
            alt="Caspian Lighting Showroom"
            fill
            className="object-cover"
          />
        </div>
      </div>

      {/* Mission and Values */}
      <div className="bg-amber-50 rounded-lg p-8 mb-20">
        <div className="text-center mb-12">
          <h2 className="text-2xl font-bold mb-4">Our Mission & Values</h2>
          <p className="max-w-3xl mx-auto">
            At Caspian Lighting, we believe that lighting is more than just illumination—it's about creating atmosphere,
            enhancing architecture, and improving quality of life.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-3">
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="rounded-full bg-amber-100 p-3 w-12 h-12 flex items-center justify-center mb-4">
              <Lightbulb className="h-6 w-6 text-amber-600" />
            </div>
            <h3 className="text-lg font-bold mb-2">Innovation</h3>
            <p className="text-muted-foreground">
              We continuously explore new technologies and design approaches to offer cutting-edge lighting solutions.
            </p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="rounded-full bg-amber-100 p-3 w-12 h-12 flex items-center justify-center mb-4">
              <Award className="h-6 w-6 text-amber-600" />
            </div>
            <h3 className="text-lg font-bold mb-2">Quality</h3>
            <p className="text-muted-foreground">
              We source only the finest materials and partner with trusted manufacturers to ensure exceptional quality.
            </p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="rounded-full bg-amber-100 p-3 w-12 h-12 flex items-center justify-center mb-4">
              <Users className="h-6 w-6 text-amber-600" />
            </div>
            <h3 className="text-lg font-bold mb-2">Customer Focus</h3>
            <p className="text-muted-foreground">
              We prioritize understanding our customers' needs and providing personalized solutions and support.
            </p>
          </div>
        </div>
      </div>

      {/* Team */}
      <div className="mb-20">
        <div className="text-center mb-12">
          <h2 className="text-2xl font-bold mb-4">Our Team</h2>
          <p className="max-w-3xl mx-auto">
            Our diverse team of lighting experts, designers, and customer service professionals work together to deliver
            exceptional lighting solutions and experiences.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-4">
          {[
            {
              name: "Eldar Mammadov",
              position: "Founder & CEO",
              image: "/placeholder.svg?height=300&width=300&text=EM",
            },
            {
              name: "Leyla Aliyeva",
              position: "Design Director",
              image: "/placeholder.svg?height=300&width=300&text=LA",
            },
            {
              name: "Farid Huseynov",
              position: "Technical Manager",
              image: "/placeholder.svg?height=300&width=300&text=FH",
            },
            {
              name: "Aysel Karimova",
              position: "Customer Relations",
              image: "/placeholder.svg?height=300&width=300&text=AK",
            },
          ].map((member, index) => (
            <div key={index} className="text-center">
              <div className="relative h-64 mb-4 rounded-lg overflow-hidden">
                <Image src={member.image || "/placeholder.svg"} alt={member.name} fill className="object-cover" />
              </div>
              <h3 className="font-bold">{member.name}</h3>
              <p className="text-muted-foreground">{member.position}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Global Presence */}
      <div className="grid gap-12 md:grid-cols-2 items-center mb-20">
        <div className="relative h-[400px] rounded-lg overflow-hidden">
          <Image
            src="/placeholder.svg?height=400&width=600&text=Global+Presence"
            alt="Caspian Lighting Global Presence"
            fill
            className="object-cover"
          />
        </div>
        <div>
          <h2 className="text-2xl font-bold mb-4">Global Presence</h2>
          <p className="mb-4">
            While our roots are in Azerbaijan, our influence extends across the Caucasus region and beyond. We've
            completed projects in Georgia, Turkey, Russia, and the UAE, bringing our distinctive lighting solutions to
            diverse spaces around the world.
          </p>
          <p className="mb-4">
            Our international partnerships with leading manufacturers in Italy, Germany, and Spain allow us to offer a
            curated selection of the world's finest lighting products alongside our own custom designs.
          </p>
          <div className="flex items-center gap-2 mb-2">
            <Globe className="h-5 w-5 text-amber-600" />
            <span className="font-medium">Headquarters:</span> Baku, Azerbaijan
          </div>
          <div className="flex items-center gap-2">
            <Globe className="h-5 w-5 text-amber-600" />
            <span className="font-medium">Showrooms:</span> Baku, Tbilisi, Istanbul
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="bg-amber-600 text-white rounded-lg p-12 text-center">
        <h2 className="text-2xl font-bold mb-4">Ready to Transform Your Space?</h2>
        <p className="max-w-2xl mx-auto mb-8">
          Whether you're looking for a single statement piece or a complete lighting solution for your project, our team
          is here to help.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/20">
            <Link href="/products">Explore Our Products</Link>
          </Button>
          <Button size="lg" className="bg-white text-amber-600 hover:bg-white/90">
            <Link href="/contact">Contact Us</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
