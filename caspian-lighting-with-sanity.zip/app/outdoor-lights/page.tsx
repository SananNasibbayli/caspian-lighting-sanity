import OutdoorLightsPage from "./index-page"

export default OutdoorLightsPage

export const metadata = {
  title: "Outdoor Lights | Caspian Lighting",
  description: "Find the perfect outdoor lighting solutions for your garden, patio, or exterior spaces",
}
