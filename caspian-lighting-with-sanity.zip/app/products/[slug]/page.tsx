import { notFound } from "next/navigation"
import { getProduct } from "@/lib/payload-utils"
import { getRelatedProducts } from "@/lib/payload-utils"
import { formatPrice } from "@/lib/utils"
import { RichText } from "@/components/rich-text"
import ProductGallery from "@/components/product-gallery"
import RelatedProducts from "@/components/related-products"
import ProductSpecsChart from "@/components/product-specs-chart"
import AddToCartButton from "@/components/add-to-cart-button"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export async function generateMetadata({ params }: { params: { slug: string } }) {
  const product = await getProduct({ slug: params.slug })

  if (!product) {
    return {
      title: "Product Not Found",
      description: "The requested product could not be found",
    }
  }

  return {
    title: `${product.title} | Caspian Lighting`,
    description: product.description,
    openGraph: {
      images: [{ url: product.images?.[0]?.image?.url || "" }],
    },
  }
}

export default async function ProductPage({ params }: { params: { slug: string } }) {
  const product = await getProduct({ slug: params.slug })

  if (!product) {
    notFound()
  }

  const relatedProducts = await getRelatedProducts({
    category: product.category.id,
    currentProductId: product.id,
    limit: 4,
  })

  // Extract specifications for the chart
  const specifications = product.specifications || {}
  const specEntries = Object.entries(specifications).filter(([key]) => key !== "customSpecifications")

  // Add custom specifications if they exist
  if (specifications.customSpecifications && Array.isArray(specifications.customSpecifications)) {
    specifications.customSpecifications.forEach((spec: any) => {
      if (spec.name && spec.value) {
        specEntries.push([spec.name, spec.value])
      }
    })
  }

  return (
    <div className="container py-12 md:py-16">
      <Breadcrumb className="mb-8">
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink href="/">Home</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink href="/products">Products</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink href={`/products/categories/${product.category.slug}`}>
              {product.category.title}
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink href={`/products/${product.slug}`} isCurrentPage>
              {product.title}
            </BreadcrumbLink>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>

      <div className="grid gap-12 md:grid-cols-2">
        {/* Product Gallery */}
        <ProductGallery images={product.images} />

        {/* Product Details */}
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold">{product.title}</h1>
            <p className="mt-2 text-2xl font-semibold text-amber-600">{formatPrice(product.price)}</p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="font-medium">Category:</span>
              <a href={`/products/categories/${product.category.slug}`} className="text-amber-600 hover:underline">
                {product.category.title}
              </a>
            </div>

            <div className="flex items-center gap-2">
              <span className="font-medium">SKU:</span>
              <span>{product.sku}</span>
            </div>

            {product.inStock ? (
              <div className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-sm font-medium text-green-800">
                In Stock
              </div>
            ) : (
              <div className="inline-flex items-center rounded-full bg-red-100 px-2.5 py-0.5 text-sm font-medium text-red-800">
                Out of Stock
              </div>
            )}
          </div>

          <div className="prose max-w-none">
            <RichText content={product.content} />
          </div>

          <div className="pt-4">
            <AddToCartButton product={product} />
          </div>
        </div>
      </div>

      {/* Product Tabs */}
      <div className="mt-16">
        <Tabs defaultValue="specifications" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="specifications">Specifications</TabsTrigger>
            <TabsTrigger value="installation">Installation Guide</TabsTrigger>
            <TabsTrigger value="warranty">Warranty Information</TabsTrigger>
          </TabsList>
          <TabsContent value="specifications" className="pt-6">
            <div className="grid gap-8 md:grid-cols-2">
              <div>
                <h3 className="mb-4 text-lg font-medium">Technical Specifications</h3>
                <ul className="space-y-2">
                  {specEntries.map(([key, value]) => (
                    <li key={key} className="flex justify-between border-b pb-2">
                      <span className="font-medium">{key}</span>
                      <span>{value}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h3 className="mb-4 text-lg font-medium">Specifications Chart</h3>
                <ProductSpecsChart specifications={specEntries} />
              </div>
            </div>
          </TabsContent>
          <TabsContent value="installation" className="pt-6">
            <div className="prose max-w-none">
              <h3>Installation Guide</h3>
              <p>
                Follow these steps to properly install your {product.title}. For professional installation services,
                please contact our customer support.
              </p>
              <ol>
                <li>Turn off the power at the circuit breaker before beginning installation.</li>
                <li>Remove the existing fixture if applicable.</li>
                <li>Connect the wires according to the included wiring diagram.</li>
                <li>Secure the mounting bracket to the junction box.</li>
                <li>Attach the fixture to the mounting bracket.</li>
                <li>Install the bulbs (not included) according to the specifications.</li>
                <li>Restore power and test the fixture.</li>
              </ol>
              <p>
                <strong>Note:</strong> We recommend professional installation for complex lighting fixtures. Improper
                installation may void the warranty.
              </p>
            </div>
          </TabsContent>
          <TabsContent value="warranty" className="pt-6">
            <div className="prose max-w-none">
              <h3>Warranty Information</h3>
              <p>
                All Caspian Lighting products come with a standard 2-year limited warranty against manufacturing
                defects. Premium products, including this {product.title}, may include an extended warranty period.
              </p>
              <h4>What's Covered:</h4>
              <ul>
                <li>Manufacturing defects in materials and workmanship</li>
                <li>Electrical components (excluding bulbs)</li>
                <li>Finish deterioration under normal indoor use</li>
              </ul>
              <h4>What's Not Covered:</h4>
              <ul>
                <li>Damage from improper installation</li>
                <li>Normal wear and tear</li>
                <li>Damage from environmental factors</li>
                <li>Light bulbs and other consumable parts</li>
              </ul>
              <p>
                To make a warranty claim, please contact our customer service department with your proof of purchase and
                product details.
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <div className="mt-20">
          <h2 className="mb-8 text-2xl font-bold">Related Products</h2>
          <RelatedProducts products={relatedProducts} />
        </div>
      )}
    </div>
  )
}
