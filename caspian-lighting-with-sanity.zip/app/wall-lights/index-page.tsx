import { getProductsByCategory } from "@/lib/payload-utils"
import { getCategoryBySlug } from "@/lib/payload-utils"
import ProductGrid from "@/components/product-grid"
import { Pagination } from "@/components/pagination"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export const metadata = {
  title: "Wall Lights | Caspian Lighting",
  description: "Browse our selection of stylish wall lights and sconces for any room",
}

export default async function WallLightsPage({
  searchParams,
}: {
  searchParams: { [key: string]: string | string[] | undefined }
}) {
  // Get query parameters
  const page = typeof searchParams.page === "string" ? Number.parseInt(searchParams.page) : 1
  const limit = 9
  const sort = typeof searchParams.sort === "string" ? searchParams.sort : "latest"

  // Fetch category
  const category = await getCategoryBySlug("wall-lights")

  if (!category) {
    return (
      <div className="container py-12 md:py-16">
        <div className="text-center">
          <h1 className="text-3xl font-bold md:text-4xl">Wall Lights</h1>
          <p className="mt-4 text-muted-foreground">Category not found. Please check back later.</p>
        </div>
      </div>
    )
  }

  // Fetch products for this category
  const { products, totalProducts, totalPages } = await getProductsByCategory({
    categoryId: category.id,
    page,
    limit,
    sort,
    depth: 1,
  })

  return (
    <div className="container py-12 md:py-16">
      <div className="mb-12 text-center">
        <h1 className="text-3xl font-bold md:text-4xl">Wall Lights</h1>
        <p className="mt-4 max-w-3xl mx-auto text-muted-foreground">
          Transform your walls with our diverse collection of wall lights and sconces. Perfect for adding ambient
          lighting, creating focal points, or illuminating hallways and corridors with style and sophistication.
        </p>
      </div>

      {/* Featured Section */}
      <div className="mb-16 bg-amber-50 rounded-lg overflow-hidden">
        <div className="grid md:grid-cols-2 items-center">
          <div className="p-8 md:p-12">
            <h2 className="text-2xl font-bold mb-4">Illuminate Your Walls</h2>
            <p className="mb-6">
              Wall lights are versatile fixtures that add depth and dimension to your space. From sleek modern sconces
              to ornate traditional designs, our collection offers options for every style and setting.
            </p>
            <Button className="bg-amber-600 hover:bg-amber-700">
              <a href="#products" className="flex items-center">
                Explore Collection <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
          </div>
          <div className="h-[400px] bg-amber-200">
            <img
              src="/placeholder.svg?height=400&width=600&text=Wall+Lights"
              alt="Wall Lights Collection"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>

      {/* Wall Light Types */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-8 text-center">Wall Light Styles</h2>
        <div className="grid md:grid-cols-4 gap-6">
          {[
            {
              title: "Sconces",
              description: "Classic wall-mounted fixtures for ambient lighting",
              image: "/placeholder.svg?height=300&width=300&text=Sconces",
            },
            {
              title: "Picture Lights",
              description: "Designed to illuminate artwork and photographs",
              image: "/placeholder.svg?height=300&width=300&text=Picture+Lights",
            },
            {
              title: "Reading Lights",
              description: "Adjustable fixtures perfect beside beds or seating",
              image: "/placeholder.svg?height=300&width=300&text=Reading+Lights",
            },
            {
              title: "Bathroom Lights",
              description: "Water-resistant designs for bathroom illumination",
              image: "/placeholder.svg?height=300&width=300&text=Bathroom+Lights",
            },
          ].map((style, index) => (
            <div key={index} className="text-center">
              <div className="rounded-full overflow-hidden w-40 h-40 mx-auto mb-4">
                <img src={style.image || "/placeholder.svg"} alt={style.title} className="w-full h-full object-cover" />
              </div>
              <h3 className="font-bold mb-2">{style.title}</h3>
              <p className="text-sm text-muted-foreground">{style.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Design Tips */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-8 text-center">Wall Light Design Tips</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="border rounded-lg p-6">
            <h3 className="font-bold mb-3">Optimal Placement</h3>
            <p className="text-muted-foreground">
              Install wall sconces at eye level (approximately 5.5 to 6 feet from the floor) to avoid glare. In
              bathrooms, place vanity lights 75-80 inches from the floor.
            </p>
          </div>
          <div className="border rounded-lg p-6">
            <h3 className="font-bold mb-3">Spacing Guidelines</h3>
            <p className="text-muted-foreground">
              For hallways, space wall lights 8-10 feet apart. When flanking a mirror or artwork, position sconces 36-40
              inches apart for balanced illumination.
            </p>
          </div>
          <div className="border rounded-lg p-6">
            <h3 className="font-bold mb-3">Layered Lighting</h3>
            <p className="text-muted-foreground">
              Combine wall lights with ceiling fixtures and table lamps to create a well-balanced lighting scheme with
              multiple layers for different activities and moods.
            </p>
          </div>
        </div>
      </div>

      {/* Products */}
      <div id="products" className="mb-16">
        <h2 className="text-2xl font-bold mb-8">Our Wall Light Collection</h2>

        {products.length > 0 ? (
          <>
            <div className="mb-8">
              <p className="text-sm text-muted-foreground">
                Showing {products.length} of {totalProducts} wall lights
              </p>
            </div>

            <ProductGrid products={products} />

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="mt-8 flex justify-center">
                <Pagination totalPages={totalPages} currentPage={page} />
              </div>
            )}
          </>
        ) : (
          <div className="flex h-[400px] items-center justify-center rounded-md border border-dashed">
            <div className="text-center">
              <h3 className="text-lg font-medium">No products found</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                We're currently updating our collection. Please check back soon.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Room Ideas */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-8 text-center">Wall Light Ideas by Room</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              room: "Living Room",
              description: "Create ambiance with decorative sconces that complement your decor",
              image: "/placeholder.svg?height=300&width=300&text=Living+Room",
            },
            {
              room: "Bedroom",
              description: "Install reading lights on either side of the bed for comfortable nighttime reading",
              image: "/placeholder.svg?height=300&width=300&text=Bedroom",
            },
            {
              room: "Bathroom",
              description: "Use vanity lights for task lighting and sconces for ambient illumination",
              image: "/placeholder.svg?height=300&width=300&text=Bathroom",
            },
            {
              room: "Hallway",
              description: "Illuminate corridors with evenly spaced wall lights for safety and style",
              image: "/placeholder.svg?height=300&width=300&text=Hallway",
            },
          ].map((room, index) => (
            <div key={index} className="border rounded-lg overflow-hidden">
              <div className="h-48">
                <img src={room.image || "/placeholder.svg"} alt={room.room} className="w-full h-full object-cover" />
              </div>
              <div className="p-4">
                <h3 className="font-bold mb-2">{room.room}</h3>
                <p className="text-sm text-muted-foreground">{room.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="bg-amber-600 text-white rounded-lg p-12 text-center">
        <h2 className="text-2xl font-bold mb-4">Need Help With Your Wall Lighting?</h2>
        <p className="max-w-2xl mx-auto mb-8">
          Our lighting experts can help you select the perfect wall lights for your space and provide professional
          installation services.
        </p>
        <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/20">
          <a href="/contact">Contact Our Experts</a>
        </Button>
      </div>
    </div>
  )
}
