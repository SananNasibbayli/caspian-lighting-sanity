import SpotlightsPage from "./index-page"

export default SpotlightsPage

export const metadata = {
  title: "Spotlights | Caspian Lighting",
  description: "Discover our range of spotlights for focused illumination and accent lighting",
}
