import Link from "next/link"
import { Facebook, Instagram, Twitter } from "lucide-react"

export default function SiteFooter() {
  return (
    <footer className="w-full border-t bg-white py-6 md:py-12">
      <div className="container grid gap-8 px-4 md:grid-cols-2 md:px-6 lg:grid-cols-4">
        <div className="space-y-4">
          <Link href="/" className="flex items-center space-x-2">
            <span className="text-xl font-bold tracking-tight text-amber-600">Caspian Lighting</span>
          </Link>
          <p className="text-sm text-muted-foreground">
            Premium lighting solutions for homes, offices, and design projects since 2005.
          </p>
          <div className="flex space-x-4">
            <Link href="#" className="text-muted-foreground hover:text-amber-600">
              <Facebook className="h-5 w-5" />
              <span className="sr-only">Facebook</span>
            </Link>
            <Link href="#" className="text-muted-foreground hover:text-amber-600">
              <Instagram className="h-5 w-5" />
              <span className="sr-only">Instagram</span>
            </Link>
            <Link href="#" className="text-muted-foreground hover:text-amber-600">
              <Twitter className="h-5 w-5" />
              <span className="sr-only">Twitter</span>
            </Link>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-sm font-medium">Collections</h3>
          <nav className="flex flex-col space-y-2 text-sm">
            <Link href="#" className="text-muted-foreground hover:text-amber-600">
              Chandeliers
            </Link>
            <Link href="#" className="text-muted-foreground hover:text-amber-600">
              Wall Lights
            </Link>
            <Link href="#" className="text-muted-foreground hover:text-amber-600">
              Spotlights
            </Link>
            <Link href="#" className="text-muted-foreground hover:text-amber-600">
              Outdoor Lights
            </Link>
            <Link href="#" className="text-muted-foreground hover:text-amber-600">
              Smart Lighting
            </Link>
          </nav>
        </div>

        <div className="space-y-4">
          <h3 className="text-sm font-medium">Company</h3>
          <nav className="flex flex-col space-y-2 text-sm">
            <Link href="#" className="text-muted-foreground hover:text-amber-600">
              About Us
            </Link>
            <Link href="#" className="text-muted-foreground hover:text-amber-600">
              Projects
            </Link>
            <Link href="#" className="text-muted-foreground hover:text-amber-600">
              Blog
            </Link>
            <Link href="#" className="text-muted-foreground hover:text-amber-600">
              Careers
            </Link>
            <Link href="#" className="text-muted-foreground hover:text-amber-600">
              Contact
            </Link>
          </nav>
        </div>

        <div className="space-y-4">
          <h3 className="text-sm font-medium">Contact Information</h3>
          <div className="flex flex-col space-y-2 text-sm text-muted-foreground">
            <p>123 Lighting Avenue, Baku, Azerbaijan</p>
            <p>Opening Hours: Mon-Fri 9:00 - 18:00</p>
            <p>Email: info@caspianlighting.az</p>
            <p>Phone: +994 12 345 6789</p>
          </div>
        </div>
      </div>
      <div className="container mt-8 border-t pt-6">
        <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
          <p className="text-xs text-muted-foreground">
            &copy; {new Date().getFullYear()} Caspian Lighting. All rights reserved.
          </p>
          <nav className="flex gap-4 text-xs">
            <Link href="#" className="text-muted-foreground hover:text-amber-600">
              Terms of Service
            </Link>
            <Link href="#" className="text-muted-foreground hover:text-amber-600">
              Privacy Policy
            </Link>
            <Link href="#" className="text-muted-foreground hover:text-amber-600">
              Cookie Policy
            </Link>
          </nav>
        </div>
      </div>
    </footer>
  )
}
