import { notFound } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { getProject } from "@/lib/payload-utils"
import { RichText } from "@/components/rich-text"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"

export async function generateMetadata({ params }: { params: { slug: string } }) {
  const project = await getProject({ slug: params.slug })

  if (!project) {
    return {
      title: "Project Not Found",
      description: "The requested project could not be found",
    }
  }

  return {
    title: `${project.title} | Caspian Lighting Projects`,
    description: project.description,
    openGraph: {
      images: [{ url: project.images?.[0]?.image?.url || "" }],
    },
  }
}

export default async function ProjectPage({ params }: { params: { slug: string } }) {
  const project = await getProject({ slug: params.slug })

  if (!project) {
    notFound()
  }

  return (
    <div className="container py-12 md:py-16">
      <Breadcrumb className="mb-8">
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink href="/">Home</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink href="/projects">Projects</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink href={`/projects/${project.slug}`} isCurrentPage>
              {project.title}
            </BreadcrumbLink>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>

      <div className="mb-8">
        <div className="flex flex-wrap items-center gap-4 mb-4">
          <h1 className="text-3xl font-bold md:text-4xl">{project.title}</h1>
          <div className="rounded-full bg-amber-100 px-3 py-1 text-sm text-amber-800">
            {project.category?.title || "Project"}
          </div>
        </div>
        <p className="text-xl text-muted-foreground">{project.description}</p>
      </div>

      {/* Project Gallery */}
      <div className="mb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {project.images?.map((image: any, index: number) => (
            <div
              key={index}
              className={`overflow-hidden rounded-lg ${index === 0 ? "md:col-span-2 md:row-span-2" : ""}`}
            >
              <Image
                src={image.image?.url || "/placeholder.svg"}
                alt={image.alt || `Project image ${index + 1}`}
                width={800}
                height={600}
                className="w-full h-full object-cover"
              />
            </div>
          ))}
        </div>
      </div>

      {/* Project Details */}
      <div className="grid md:grid-cols-3 gap-12">
        <div className="md:col-span-2">
          <Tabs defaultValue="overview">
            <TabsList className="mb-6">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="challenge">Challenge</TabsTrigger>
              <TabsTrigger value="solution">Solution</TabsTrigger>
              <TabsTrigger value="results">Results</TabsTrigger>
            </TabsList>
            <TabsContent value="overview" className="prose max-w-none">
              <RichText content={project.content} />
              {!project.content && (
                <div>
                  <p>
                    This project showcases our expertise in creating custom lighting solutions tailored to the specific
                    needs and aesthetics of the space. Working closely with the client and design team, we developed a
                    comprehensive lighting plan that enhances the architecture while providing functional illumination.
                  </p>
                  <p>
                    Our approach focused on balancing ambient, task, and accent lighting to create layers of light that
                    add depth and dimension to the space. We carefully selected fixtures that complement the interior
                    design while meeting the technical requirements for light output and energy efficiency.
                  </p>
                </div>
              )}
            </TabsContent>
            <TabsContent value="challenge" className="prose max-w-none">
              <h3>The Challenge</h3>
              <p>The client needed a lighting solution that would:</p>
              <ul>
                <li>Enhance the architectural features of the space</li>
                <li>Provide adequate illumination for various activities</li>
                <li>Meet energy efficiency requirements</li>
                <li>Complement the interior design aesthetic</li>
                <li>Allow for flexible control and scene setting</li>
              </ul>
              <p>
                Additionally, the installation timeline was tight, requiring careful coordination with other trades and
                precise project management.
              </p>
            </TabsContent>
            <TabsContent value="solution" className="prose max-w-none">
              <h3>Our Solution</h3>
              <p>We developed a comprehensive lighting design that included:</p>
              <ul>
                <li>Custom chandeliers for statement areas</li>
                <li>Recessed lighting for general illumination</li>
                <li>Wall sconces for accent lighting</li>
                <li>Task lighting for functional areas</li>
                <li>Smart lighting controls for energy efficiency and scene setting</li>
              </ul>
              <p>
                Our team worked closely with architects, interior designers, and electrical contractors to ensure
                seamless integration of the lighting system with the overall design and construction process.
              </p>
            </TabsContent>
            <TabsContent value="results" className="prose max-w-none">
              <h3>The Results</h3>
              <p>The completed project achieved all the client's objectives:</p>
              <ul>
                <li>Enhanced architectural features through strategic lighting placement</li>
                <li>Created a welcoming and functional environment</li>
                <li>Reduced energy consumption through efficient fixtures and smart controls</li>
                <li>Received positive feedback from users and visitors</li>
                <li>Completed on time and within budget</li>
              </ul>
              <p>
                The client was extremely satisfied with the results, noting that the lighting has transformed the space
                and significantly improved the overall experience.
              </p>
            </TabsContent>
          </Tabs>
        </div>

        <div>
          <div className="border rounded-lg p-6 sticky top-24">
            <h3 className="text-lg font-bold mb-4">Project Details</h3>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground">Category</p>
                <p className="font-medium">{project.category?.title || "Uncategorized"}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Location</p>
                <p className="font-medium">{project.location || "Baku, Azerbaijan"}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Completed</p>
                <p className="font-medium">
                  {project.completedAt
                    ? new Date(project.completedAt).toLocaleDateString("en-US", {
                        year: "numeric",
                        month: "long",
                      })
                    : "2023"}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Services</p>
                <p className="font-medium">
                  {project.services?.join(", ") || "Lighting Design, Installation, Custom Fixtures"}
                </p>
              </div>
              <div className="pt-4">
                <Button className="w-full bg-amber-600 hover:bg-amber-700">
                  <Link href="/contact">Inquire About Similar Projects</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Related Projects */}
      <div className="mt-20">
        <h2 className="text-2xl font-bold mb-8">More Projects</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {/* Mock related projects - in a real app, these would be fetched from the API */}
          {[1, 2, 3].map((i) => (
            <div key={i} className="border rounded-lg overflow-hidden group">
              <div className="h-48 bg-gray-100 overflow-hidden">
                <img
                  src={`/placeholder.svg?height=300&width=400&text=Project+${i}`}
                  alt={`Project ${i}`}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
              </div>
              <div className="p-4">
                <p className="text-sm text-muted-foreground">{["Hotel", "Residential", "Commercial"][i - 1]}</p>
                <h3 className="font-bold hover:text-amber-600">
                  <Link href={`/projects/project-${i}`}>
                    {["Luxury Hotel Lighting", "Modern Home Illumination", "Office Complex Lighting"][i - 1]}
                  </Link>
                </h3>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="mt-20 bg-amber-50 rounded-lg p-8 text-center">
        <h2 className="text-2xl font-bold mb-4">Ready to Start Your Project?</h2>
        <p className="max-w-2xl mx-auto mb-6">
          Contact our team to discuss your lighting needs and how we can help bring your vision to life.
        </p>
        <Button size="lg" className="bg-amber-600 hover:bg-amber-700">
          <Link href="/contact">Contact Us</Link>
        </Button>
      </div>
    </div>
  )
}
