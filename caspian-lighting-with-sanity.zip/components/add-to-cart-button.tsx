"use client"

import { useState } from "react"
import { ShoppingCart, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { useCart } from "@/lib/cart-context"

type AddToCartButtonProps = {
  product: any
  variant?: "default" | "outline" | "secondary"
  size?: "default" | "sm" | "lg" | "icon"
  showIcon?: boolean
}

export default function AddToCartButton({
  product,
  variant = "default",
  size = "default",
  showIcon = true,
}: AddToCartButtonProps) {
  const [isAdding, setIsAdding] = useState(false)
  const { toast } = useToast()
  const { addToCart } = useCart()

  const handleAddToCart = () => {
    if (!product.inStock) return

    setIsAdding(true)

    // Simulate adding to cart
    setTimeout(() => {
      addToCart({
        id: product.id,
        title: product.title,
        price: product.price,
        image: product.images?.[0]?.image?.url,
        slug: product.slug,
        quantity: 1,
      })

      toast({
        title: "Added to cart",
        description: `${product.title} has been added to your cart.`,
      })

      setIsAdding(false)
    }, 600)
  }

  return (
    <Button
      variant={variant}
      size={size}
      className={variant === "default" ? "bg-amber-600 hover:bg-amber-700" : ""}
      disabled={!product.inStock || isAdding}
      onClick={handleAddToCart}
    >
      {isAdding ? (
        <>
          <Check className="mr-2 h-4 w-4 animate-in fade-in" />
          Added
        </>
      ) : (
        <>
          {showIcon && <ShoppingCart className="mr-2 h-4 w-4" />}
          {product.inStock ? "Add to Cart" : "Out of Stock"}
        </>
      )}
    </Button>
  )
}
