import { getProductsByCategory } from "@/lib/payload-utils"
import { getCategoryBySlug } from "@/lib/payload-utils"
import ProductGrid from "@/components/product-grid"
import { Pagination } from "@/components/pagination"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export const metadata = {
  title: "Spotlights | Caspian Lighting",
  description: "Discover our range of spotlights for focused illumination and accent lighting",
}

export default async function SpotlightsPage({
  searchParams,
}: {
  searchParams: { [key: string]: string | string[] | undefined }
}) {
  // Get query parameters
  const page = typeof searchParams.page === "string" ? Number.parseInt(searchParams.page) : 1
  const limit = 9
  const sort = typeof searchParams.sort === "string" ? searchParams.sort : "latest"

  // Fetch category
  const category = await getCategoryBySlug("spotlights")

  if (!category) {
    return (
      <div className="container py-12 md:py-16">
        <div className="text-center">
          <h1 className="text-3xl font-bold md:text-4xl">Spotlights</h1>
          <p className="mt-4 text-muted-foreground">Category not found. Please check back later.</p>
        </div>
      </div>
    )
  }

  // Fetch products for this category
  const { products, totalProducts, totalPages } = await getProductsByCategory({
    categoryId: category.id,
    page,
    limit,
    sort,
    depth: 1,
  })

  return (
    <div className="container py-12 md:py-16">
      <div className="mb-12 text-center">
        <h1 className="text-3xl font-bold md:text-4xl">Spotlights</h1>
        <p className="mt-4 max-w-3xl mx-auto text-muted-foreground">
          Highlight architectural features, artwork, or specific areas with our precision-engineered spotlights. From
          adjustable track lighting to recessed downlights, our collection offers focused illumination with style and
          efficiency.
        </p>
      </div>

      {/* Featured Section */}
      <div className="mb-16 bg-amber-50 rounded-lg overflow-hidden">
        <div className="grid md:grid-cols-2 items-center">
          <div className="p-8 md:p-12">
            <h2 className="text-2xl font-bold mb-4">Focused Illumination</h2>
            <p className="mb-6">
              Spotlights provide directional light that adds drama and focus to your space. Whether you're highlighting
              artwork, creating task lighting, or adding accent lighting to architectural features, our spotlight
              collection offers precision and style.
            </p>
            <Button className="bg-amber-600 hover:bg-amber-700">
              <a href="#products" className="flex items-center">
                Explore Collection <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
          </div>
          <div className="h-[400px] bg-amber-200">
            <img
              src="/placeholder.svg?height=400&width=600&text=Spotlights"
              alt="Spotlight Collection"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>

      {/* Spotlight Types */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-8 text-center">Spotlight Types</h2>
        <div className="grid md:grid-cols-4 gap-6">
          {[
            {
              title: "Track Lighting",
              description: "Adjustable spotlights mounted on a track for flexible positioning",
              image: "/placeholder.svg?height=300&width=300&text=Track",
            },
            {
              title: "Recessed Downlights",
              description: "Ceiling-embedded fixtures for clean, minimalist illumination",
              image: "/placeholder.svg?height=300&width=300&text=Recessed",
            },
            {
              title: "Surface Spotlights",
              description: "Mounted directly on ceilings or walls for easy installation",
              image: "/placeholder.svg?height=300&width=300&text=Surface",
            },
            {
              title: "Adjustable Spotlights",
              description: "Directional fixtures that can be aimed precisely where needed",
              image: "/placeholder.svg?height=300&width=300&text=Adjustable",
            },
          ].map((type, index) => (
            <div key={index} className="text-center">
              <div className="rounded-full overflow-hidden w-40 h-40 mx-auto mb-4">
                <img src={type.image || "/placeholder.svg"} alt={type.title} className="w-full h-full object-cover" />
              </div>
              <h3 className="font-bold mb-2">{type.title}</h3>
              <p className="text-sm text-muted-foreground">{type.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Technical Guide */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-8 text-center">Spotlight Technical Guide</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="border rounded-lg p-6">
            <h3 className="font-bold mb-3">Beam Angles</h3>
            <p className="text-muted-foreground">
              Narrow beam angles (15-30°) create focused light for highlighting specific objects. Medium beams (30-45°)
              provide balanced accent lighting. Wide beams (45-60°) offer more general illumination.
            </p>
          </div>
          <div className="border rounded-lg p-6">
            <h3 className="font-bold mb-3">Color Temperature</h3>
            <p className="text-muted-foreground">
              Warm white (2700-3000K) creates a cozy atmosphere. Neutral white (3500-4000K) is versatile for most
              spaces. Cool white (5000-6500K) enhances focus and is ideal for task lighting.
            </p>
          </div>
          <div className="border rounded-lg p-6">
            <h3 className="font-bold mb-3">Dimming Capabilities</h3>
            <p className="text-muted-foreground">
              Many of our spotlights are dimmable, allowing you to adjust light levels for different activities and
              moods. Check product specifications for compatibility with your dimming system.
            </p>
          </div>
        </div>
      </div>

      {/* Products */}
      <div id="products" className="mb-16">
        <h2 className="text-2xl font-bold mb-8">Our Spotlight Collection</h2>

        {products.length > 0 ? (
          <>
            <div className="mb-8">
              <p className="text-sm text-muted-foreground">
                Showing {products.length} of {totalProducts} spotlights
              </p>
            </div>

            <ProductGrid products={products} />

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="mt-8 flex justify-center">
                <Pagination totalPages={totalPages} currentPage={page} />
              </div>
            )}
          </>
        ) : (
          <div className="flex h-[400px] items-center justify-center rounded-md border border-dashed">
            <div className="text-center">
              <h3 className="text-lg font-medium">No products found</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                We're currently updating our collection. Please check back soon.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Application Ideas */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-8 text-center">Spotlight Applications</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              application: "Art Highlighting",
              description: "Illuminate paintings, sculptures, and other artwork to enhance their visual impact",
              image: "/placeholder.svg?height=300&width=300&text=Art",
            },
            {
              application: "Retail Displays",
              description: "Draw attention to merchandise and create an engaging shopping environment",
              image: "/placeholder.svg?height=300&width=300&text=Retail",
            },
            {
              application: "Kitchen Task Lighting",
              description: "Provide focused illumination for food preparation and cooking areas",
              image: "/placeholder.svg?height=300&width=300&text=Kitchen",
            },
            {
              application: "Architectural Features",
              description: "Highlight textured walls, columns, or other architectural elements",
              image: "/placeholder.svg?height=300&width=300&text=Architecture",
            },
          ].map((app, index) => (
            <div key={index} className="border rounded-lg overflow-hidden">
              <div className="h-48">
                <img
                  src={app.image || "/placeholder.svg"}
                  alt={app.application}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-4">
                <h3 className="font-bold mb-2">{app.application}</h3>
                <p className="text-sm text-muted-foreground">{app.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="bg-amber-600 text-white rounded-lg p-12 text-center">
        <h2 className="text-2xl font-bold mb-4">Need Expert Advice on Spotlight Placement?</h2>
        <p className="max-w-2xl mx-auto mb-8">
          Our lighting specialists can help you plan the perfect spotlight arrangement for your space, ensuring optimal
          illumination and visual impact.
        </p>
        <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/20">
          <a href="/contact">Schedule a Consultation</a>
        </Button>
      </div>
    </div>
  )
}
