import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"

type ProductHighlightsProps = {
  title: string
  subtitle: string
  products: any[]
}

export default function ProductHighlights({ title, subtitle, products }: ProductHighlightsProps) {
  // Use only the first 4 products
  const displayProducts = products.slice(0, 4)

  return (
    <section className="w-full py-12 md:py-24 lg:py-32">
      <div className="container space-y-12 px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <div className="inline-block rounded-lg bg-amber-100 px-3 py-1 text-sm text-amber-800">Our Collections</div>
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">{title}</h2>
            <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              {subtitle}
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {displayProducts.map((product) => (
            <div
              key={product.id}
              className="group relative overflow-hidden rounded-lg shadow-lg transition-all hover:shadow-xl"
            >
              <Image
                src={product.images?.[0]?.image?.url || "/placeholder.svg?height=600&width=400"}
                alt={product.title}
                width={400}
                height={600}
                className="h-80 w-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent opacity-80">
                <div className="absolute bottom-0 w-full p-6">
                  <h3 className="text-xl font-bold text-white">{product.title}</h3>
                  <p className="mb-4 text-white/80">{product.description}</p>
                  <Button variant="outline" className="border-white text-white hover:bg-white/20">
                    <Link href={`/products/${product.slug}`}>View All</Link>
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
