import { NextResponse } from "next/server"
import { z } from "zod"
import payload from "@/payload"

const formSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  phone: z.string().optional(),
  subject: z.string().min(2),
  message: z.string().min(10),
})

export async function POST(request: Request) {
  try {
    const body = await request.json()

    // Validate form data
    const result = formSchema.safeParse(body)

    if (!result.success) {
      return NextResponse.json({ error: "Invalid form data", details: result.error.format() }, { status: 400 })
    }

    const { name, email, phone, subject, message } = result.data

    // Store in Payload CMS
    await payload.create({
      collection: "contact-submissions",
      data: {
        name,
        email,
        phone,
        subject,
        message,
        status: "new",
      },
    })

    // In a real implementation, we would send an email here
    // For the preview, we'll just log it
    console.log("Would send email with:", {
      from: "noreply@caspianlighting.az",
      to: "info@caspianlighting.az",
      subject: `New Contact Form Submission: ${subject}`,
      html: `
        <h1>New Contact Form Submission</h1>
        <p><strong>Name:</strong> ${name}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Phone:</strong> ${phone || "Not provided"}</p>
        <p><strong>Subject:</strong> ${subject}</p>
        <p><strong>Message:</strong></p>
        <p>${message.replace(/\n/g, "<br />")}</p>
      `,
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Contact form error:", error)
    return NextResponse.json({ error: "Failed to process contact form" }, { status: 500 })
  }
}
