import { type NextRequest, NextResponse } from "next/server"
import { revalidatePath } from "next/cache"

export async function GET(request: NextRequest) {
  try {
    // Get the secret and path from the request
    const secret = request.nextUrl.searchParams.get("secret")
    const path = request.nextUrl.searchParams.get("path")

    // Check if the secret matches
    if (secret !== process.env.REVALIDATION_SECRET) {
      return NextResponse.json({ message: "Invalid revalidation secret" }, { status: 401 })
    }

    // Check if path is provided
    if (!path) {
      return NextResponse.json({ message: "Path parameter is required" }, { status: 400 })
    }

    // Revalidate the path
    revalidatePath(path)

    return NextResponse.json({ revalidated: true, message: `Path ${path} revalidated successfully` }, { status: 200 })
  } catch (error) {
    console.error("Error revalidating path:", error)
    return NextResponse.json({ message: "Error revalidating path" }, { status: 500 })
  }
}
