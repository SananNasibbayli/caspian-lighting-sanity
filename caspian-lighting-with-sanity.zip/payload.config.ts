import { buildConfig } from "payload/config"
import path from "path"
import { cloudStorage } from "@payloadcms/plugin-cloud-storage"
import { s3Adapter } from "@payloadcms/plugin-cloud-storage/s3"
import { mongooseAdapter } from "@payloadcms/db-mongodb"
import { webpackBundler } from "@payloadcms/bundler-webpack"
import { slateEditor } from "@payloadcms/richtext-slate"
import { payloadCloud } from "@payloadcms/plugin-cloud"

// Collections
import Users from "./collections/Users"
import Products from "./collections/Products"
import Categories from "./collections/Categories"
import Projects from "./collections/Projects"
import ProjectCategories from "./collections/ProjectCategories"
import Media from "./collections/Media"
import Pages from "./collections/Pages"
import BlogPosts from "./collections/BlogPosts"
import BlogCategories from "./collections/BlogCategories"
import ContactSubmissions from "./collections/ContactSubmissions"

// Globals
import Navigation from "./globals/Navigation"
import Footer from "./globals/Footer"
import SocialMedia from "./globals/SocialMedia"
import SiteSettings from "./globals/SiteSettings"

const adapter = s3Adapter({
  config: {
    credentials: {
      accessKeyId: process.env.S3_ACCESS_KEY_ID || "",
      secretAccessKey: process.env.S3_SECRET_ACCESS_KEY || "",
    },
    region: process.env.S3_REGION || "",
  },
  bucket: process.env.S3_BUCKET || "",
})

export default buildConfig({
  admin: {
    user: Users.slug,
    bundler: webpackBundler(),
    meta: {
      titleSuffix: "- Caspian Lighting",
      favicon: "/favicon.ico",
      ogImage: "/og-image.jpg",
    },
  },
  editor: slateEditor({}),
  db: mongooseAdapter({
    url: process.env.DATABASE_URI || "",
  }),
  serverURL: process.env.PAYLOAD_PUBLIC_SERVER_URL || "",
  collections: [
    Users,
    Products,
    Categories,
    Projects,
    ProjectCategories,
    Media,
    Pages,
    BlogPosts,
    BlogCategories,
    ContactSubmissions,
  ],
  globals: [Navigation, Footer, SocialMedia, SiteSettings],
  typescript: {
    outputFile: path.resolve(__dirname, "payload-types.ts"),
  },
  graphQL: {
    schemaOutputFile: path.resolve(__dirname, "generated-schema.graphql"),
  },
  plugins: [
    payloadCloud(),
    cloudStorage({
      collections: {
        media: {
          adapter,
        },
      },
    }),
  ],
})
