import { notFound } from "next/navigation"
import { getProductsByCategory } from "@/lib/payload-utils"
import { getCategoryBySlug } from "@/lib/payload-utils"
import ProductGrid from "@/components/product-grid"
import { Pagination } from "@/components/pagination"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"

export async function generateMetadata({ params }: { params: { slug: string } }) {
  const category = await getCategoryBySlug(params.slug)

  if (!category) {
    return {
      title: "Category Not Found",
      description: "The requested category could not be found",
    }
  }

  return {
    title: `${category.title} | Caspian Lighting`,
    description: category.description || `Browse our collection of ${category.title.toLowerCase()}`,
  }
}

export default async function CategoryPage({
  params,
  searchParams,
}: {
  params: { slug: string }
  searchParams: { [key: string]: string | string[] | undefined }
}) {
  const category = await getCategoryBySlug(params.slug)

  if (!category) {
    notFound()
  }

  // Get query parameters
  const page = typeof searchParams.page === "string" ? Number.parseInt(searchParams.page) : 1
  const limit = 12
  const sort = typeof searchParams.sort === "string" ? searchParams.sort : "latest"

  // Fetch products for this category
  const { products, totalProducts, totalPages } = await getProductsByCategory({
    categoryId: category.id,
    page,
    limit,
    sort,
    depth: 1,
  })

  return (
    <div className="container py-12 md:py-16">
      <Breadcrumb className="mb-8">
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink href="/">Home</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink href="/products">Products</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink href={`/products/categories/${category.slug}`} isCurrentPage>
              {category.title}
            </BreadcrumbLink>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>

      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold md:text-4xl">{category.title}</h1>
        <p className="mt-4 text-muted-foreground">
          {category.description || `Browse our collection of ${category.title.toLowerCase()}`}
        </p>
      </div>

      {/* Products */}
      {products.length > 0 ? (
        <>
          <div className="mb-8">
            <p className="text-sm text-muted-foreground">
              Showing {products.length} of {totalProducts} products
            </p>
          </div>

          <ProductGrid products={products} />

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="mt-8 flex justify-center">
              <Pagination totalPages={totalPages} currentPage={page} />
            </div>
          )}
        </>
      ) : (
        <div className="flex h-[400px] items-center justify-center rounded-md border border-dashed">
          <div className="text-center">
            <h3 className="text-lg font-medium">No products found</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              We're currently updating our collection. Please check back soon.
            </p>
          </div>
        </div>
      )}
    </div>
  )
}
