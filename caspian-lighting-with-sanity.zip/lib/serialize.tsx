import type React from "react"
import Link from "next/link"
import Image from "next/image"

export const serialize = (content: any): React.ReactNode => {
  if (!content) {
    return null
  }

  if (content.children && Array.isArray(content.children)) {
    return content.children.map((child, index) => serialize(child))
  }

  if (content.type === "h1") {
    return (
      <h1 key={content.id} className="mt-8 mb-4 text-3xl font-bold">
        {content.children?.map((child, index) => serialize(child))}
      </h1>
    )
  }

  if (content.type === "h2") {
    return (
      <h2 key={content.id} className="mt-8 mb-4 text-2xl font-bold">
        {content.children?.map((child, index) => serialize(child))}
      </h2>
    )
  }

  if (content.type === "h3") {
    return (
      <h3 key={content.id} className="mt-6 mb-4 text-xl font-bold">
        {content.children?.map((child, index) => serialize(child))}
      </h3>
    )
  }

  if (content.type === "h4") {
    return (
      <h4 key={content.id} className="mt-6 mb-4 text-lg font-bold">
        {content.children?.map((child, index) => serialize(child))}
      </h4>
    )
  }

  if (content.type === "h5") {
    return (
      <h5 key={content.id} className="mt-4 mb-2 text-base font-bold">
        {content.children?.map((child, index) => serialize(child))}
      </h5>
    )
  }

  if (content.type === "h6") {
    return (
      <h6 key={content.id} className="mt-4 mb-2 text-sm font-bold">
        {content.children?.map((child, index) => serialize(child))}
      </h6>
    )
  }

  if (content.type === "p") {
    return (
      <p key={content.id} className="mb-4">
        {content.children?.map((child, index) => serialize(child))}
      </p>
    )
  }

  if (content.type === "ul") {
    return (
      <ul key={content.id} className="mb-4 ml-6 list-disc">
        {content.children?.map((child, index) => serialize(child))}
      </ul>
    )
  }

  if (content.type === "ol") {
    return (
      <ol key={content.id} className="mb-4 ml-6 list-decimal">
        {content.children?.map((child, index) => serialize(child))}
      </ol>
    )
  }

  if (content.type === "li") {
    return (
      <li key={content.id} className="mb-1">
        {content.children?.map((child, index) => serialize(child))}
      </li>
    )
  }

  if (content.type === "blockquote") {
    return (
      <blockquote key={content.id} className="mb-4 border-l-4 border-amber-600 pl-4 italic">
        {content.children?.map((child, index) => serialize(child))}
      </blockquote>
    )
  }

  if (content.type === "link") {
    const isExternal = content.url?.startsWith("http")

    if (isExternal) {
      return (
        <a
          key={content.id}
          href={content.url}
          target="_blank"
          rel="noopener noreferrer"
          className="text-amber-600 hover:underline"
        >
          {content.children?.map((child, index) => serialize(child))}
        </a>
      )
    }

    return (
      <Link key={content.id} href={content.url} className="text-amber-600 hover:underline">
        {content.children?.map((child, index) => serialize(child))}
      </Link>
    )
  }

  if (content.type === "upload") {
    return (
      <div key={content.id} className="my-6">
        <Image
          src={content.value?.url || "/placeholder.svg"}
          alt={content.value?.alt || ""}
          width={content.value?.width || 800}
          height={content.value?.height || 600}
          className="rounded-lg"
        />
        {content.value?.caption && (
          <p className="mt-2 text-center text-sm text-muted-foreground">{content.value.caption}</p>
        )}
      </div>
    )
  }

  if (content.text) {
    const text = content.text

    if (content.bold) {
      return <strong key={content.id}>{text}</strong>
    }

    if (content.italic) {
      return <em key={content.id}>{text}</em>
    }

    if (content.underline) {
      return <u key={content.id}>{text}</u>
    }

    if (content.strikethrough) {
      return <s key={content.id}>{text}</s>
    }

    if (content.code) {
      return (
        <code key={content.id} className="rounded bg-muted px-1 py-0.5 font-mono text-sm">
          {text}
        </code>
      )
    }

    return text
  }

  return null
}
