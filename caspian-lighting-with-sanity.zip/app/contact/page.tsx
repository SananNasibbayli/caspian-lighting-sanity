import { getPage } from "@/lib/payload-utils"
import { RichText } from "@/components/rich-text"
import ContactForm from "@/components/contact-form"
import { MapPin, Phone, Mail, Clock } from "lucide-react"

export const metadata = {
  title: "Contact Us | Caspian Lighting",
  description: "Get in touch with Caspian Lighting for inquiries, quotes, or support",
}

export default async function ContactPage() {
  const page = await getPage({ slug: "contact" })

  return (
    <div className="container py-12 md:py-16">
      <div className="mb-12 text-center">
        <h1 className="text-3xl font-bold md:text-4xl">Contact Us</h1>
        <p className="mt-4 text-muted-foreground">Get in touch with us for inquiries, quotes, or support</p>
      </div>

      <div className="grid gap-12 md:grid-cols-2">
        <div>
          {page?.content ? (
            <div className="prose max-w-none">
              <RichText content={page.content} />
            </div>
          ) : (
            <div className="space-y-6">
              <p>We'd love to hear from you. Please fill out the form or contact us using the information below.</p>

              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <MapPin className="mt-1 h-5 w-5 text-amber-600" />
                  <div>
                    <h3 className="font-medium">Address</h3>
                    <p className="text-muted-foreground">123 Lighting Avenue, Baku, Azerbaijan</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Phone className="mt-1 h-5 w-5 text-amber-600" />
                  <div>
                    <h3 className="font-medium">Phone</h3>
                    <p className="text-muted-foreground">+994 12 345 6789</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Mail className="mt-1 h-5 w-5 text-amber-600" />
                  <div>
                    <h3 className="font-medium">Email</h3>
                    <p className="text-muted-foreground">info@caspianlighting.az</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Clock className="mt-1 h-5 w-5 text-amber-600" />
                  <div>
                    <h3 className="font-medium">Opening Hours</h3>
                    <p className="text-muted-foreground">Monday - Friday: 9:00 - 18:00</p>
                    <p className="text-muted-foreground">Saturday: 10:00 - 15:00</p>
                    <p className="text-muted-foreground">Sunday: Closed</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Map */}
          <div className="mt-8 h-[300px] overflow-hidden rounded-lg bg-muted">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d194473.42999465074!2d49.715857326953106!3d40.37627252921241!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40307d6bd6211cf9%3A0x343f6b5e7ae56c6b!2sBaku%2C%20Azerbaijan!5e0!3m2!1sen!2sus!4v1652345678901!5m2!1sen!2sus"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
        </div>

        <div>
          <div className="rounded-lg border bg-card p-6 shadow-sm">
            <h2 className="mb-6 text-xl font-semibold">Send Us a Message</h2>
            <ContactForm />
          </div>
        </div>
      </div>
    </div>
  )
}
