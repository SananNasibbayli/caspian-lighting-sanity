import { serialize } from "@/lib/serialize"

export function RichText({ content }: { content: any }) {
  if (!content) {
    return null
  }

  // For the preview environment, we might get content in a different format
  // Check if it's an array (from our mock data) or an object (from real Payload)
  if (Array.isArray(content)) {
    return (
      <div className="rich-text">
        {content.map((block, index) => (
          <p key={index}>{block.children?.[0]?.text || ""}</p>
        ))}
      </div>
    )
  }

  // Serialize the content from Payload CMS rich text format
  const serialized = serialize(content)

  return <div className="rich-text">{serialized}</div>
}
