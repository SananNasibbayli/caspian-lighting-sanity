import WallLightsPage from "./index-page"

export default WallLightsPage

export const metadata = {
  title: "Wall Lights | Caspian Lighting",
  description: "Browse our selection of stylish wall lights and sconces for any room",
}
