import Link from "next/link"
import Image from "next/image"

type ProjectCardProps = {
  project: any
}

export default function ProjectCard({ project }: ProjectCardProps) {
  return (
    <div className="group overflow-hidden rounded-lg border bg-white shadow-sm transition-all hover:shadow-md">
      <Link href={`/projects/${project.slug}`} className="block aspect-video overflow-hidden bg-gray-100">
        <Image
          src={project.images?.[0]?.image?.url || "/placeholder.svg?height=300&width=500"}
          alt={project.title}
          width={500}
          height={300}
          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
      </Link>
      <div className="p-6">
        <Link
          href={`/projects/categories/${project.category?.slug}`}
          className="mb-2 inline-block text-sm text-muted-foreground hover:text-amber-600"
        >
          {project.category?.title || "Uncategorized"}
        </Link>
        <Link href={`/projects/${project.slug}`}>
          <h3 className="mb-2 text-xl font-bold hover:text-amber-600">{project.title}</h3>
        </Link>
        <p className="line-clamp-2 text-muted-foreground">{project.description}</p>
      </div>
    </div>
  )
}
