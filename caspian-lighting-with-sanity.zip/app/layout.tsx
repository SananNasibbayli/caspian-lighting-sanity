import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import { Toaster } from "@/components/ui/toaster"
import { CartProvider } from "@/lib/cart-context"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: {
    default: "Caspian Lighting | Premium Lighting Solutions",
    template: "%s | Caspian Lighting",
  },
  description: "Premium lighting solutions for homes, offices, and design projects",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://caspianlighting.az",
    title: "Caspian Lighting | Premium Lighting Solutions",
    description: "Premium lighting solutions for homes, offices, and design projects",
    siteName: "Caspian Lighting",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <CartProvider>
          <div className="flex min-h-screen flex-col">{children}</div>
          <Toaster />
        </CartProvider>
      </body>
    </html>
  )
}
