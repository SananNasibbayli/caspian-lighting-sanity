"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

type BlogCategoriesFilterProps = {
  categories: any[]
  selectedCategory?: string
}

export default function BlogCategoriesFilter({ categories, selectedCategory }: BlogCategoriesFilterProps) {
  const pathname = usePathname()

  return (
    <div className="flex flex-wrap items-center justify-center gap-2">
      <Link
        href="/blog"
        className={cn(
          "rounded-full border px-4 py-2 text-sm transition-colors hover:bg-amber-50",
          !selectedCategory && "bg-amber-600 text-white hover:bg-amber-700",
        )}
      >
        All Posts
      </Link>
      {categories.map((category) => (
        <Link
          key={category.id}
          href={`/blog?category=${category.id}`}
          className={cn(
            "rounded-full border px-4 py-2 text-sm transition-colors hover:bg-amber-50",
            selectedCategory === category.id && "bg-amber-600 text-white hover:bg-amber-700",
          )}
        >
          {category.title}
        </Link>
      ))}
    </div>
  )
}
