"use server"

import { revalidatePath } from "next/cache"

/**
 * Server action to revalidate a specific path
 * This is a secure way to trigger revalidation without exposing environment variables
 */
export async function revalidateProductPage(slug: string) {
  try {
    const path = `/products/${slug}`
    revalidatePath(path)
    return { success: true, message: `Revalidated ${path}` }
  } catch (error) {
    console.error("Error revalidating product page:", error)
    return { success: false, message: "Failed to revalidate" }
  }
}
