import { getBlogPosts } from "@/lib/payload-utils"
import { getBlogCategories } from "@/lib/payload-utils"
import BlogPostCard from "@/components/blog-post-card"
import BlogCategoriesFilter from "@/components/blog-categories-filter"
import { Pagination } from "@/components/pagination"

export const metadata = {
  title: "Blog | Caspian Lighting",
  description: "Lighting tips, design inspiration, and project showcases from Caspian Lighting",
}

export default async function BlogPage({
  searchParams,
}: {
  searchParams: { [key: string]: string | string[] | undefined }
}) {
  // Get query parameters
  const page = typeof searchParams.page === "string" ? Number.parseInt(searchParams.page) : 1
  const limit = 9
  const category = typeof searchParams.category === "string" ? searchParams.category : undefined

  // Fetch blog posts and categories
  const { posts, totalPosts, totalPages } = await getBlogPosts({
    page,
    limit,
    category,
    depth: 2,
  })

  const categories = await getBlogCategories()

  return (
    <div className="container py-12 md:py-16">
      <div className="mb-12 text-center">
        <h1 className="text-3xl font-bold md:text-4xl">Our Blog</h1>
        <p className="mt-4 text-muted-foreground">Lighting tips, design inspiration, and project showcases</p>
      </div>

      {/* Categories Filter */}
      <BlogCategoriesFilter categories={categories} selectedCategory={category} />

      {/* Blog Posts */}
      {posts.length > 0 ? (
        <>
          <div className="mt-8 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {posts.map((post) => (
              <BlogPostCard key={post.id} post={post} />
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="mt-12 flex justify-center">
              <Pagination totalPages={totalPages} currentPage={page} />
            </div>
          )}
        </>
      ) : (
        <div className="flex h-[400px] items-center justify-center rounded-md border border-dashed">
          <div className="text-center">
            <h3 className="text-lg font-medium">No blog posts found</h3>
            <p className="mt-1 text-sm text-muted-foreground">Check back soon for new articles.</p>
          </div>
        </div>
      )}
    </div>
  )
}
