import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"

type DesignerCornerProps = {
  title: string
  description: string
  ctaText: string
  ctaLink: string
  image: string
}

export default function DesignerCorner({ title, description, ctaText, ctaLink, image }: DesignerCornerProps) {
  return (
    <section className="w-full bg-gradient-to-r from-amber-600 to-amber-800 py-12 md:py-24 lg:py-32">
      <div className="container grid items-center gap-6 px-4 md:grid-cols-2 md:px-6">
        <div className="flex flex-col justify-center space-y-4">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter text-white sm:text-4xl md:text-5xl">{title}</h2>
            <p className="max-w-[600px] text-white/90 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              {description}
            </p>
          </div>
          <div className="flex flex-col gap-2 min-[400px]:flex-row">
            <Button size="lg" className="bg-white text-amber-800 hover:bg-white/90">
              <Link href={ctaLink}>{ctaText}</Link>
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/20">
              Learn More
            </Button>
          </div>
        </div>
        <div className="flex justify-center">
          <Image
            src={image || "/placeholder.svg"}
            alt="Interior Designer Working"
            width={500}
            height={500}
            className="rounded-lg object-cover"
          />
        </div>
      </div>
    </section>
  )
}
