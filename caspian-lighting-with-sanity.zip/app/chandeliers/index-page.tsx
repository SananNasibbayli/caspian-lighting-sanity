import { getProductsByCategory } from "@/lib/payload-utils"
import { getCategoryBySlug } from "@/lib/payload-utils"
import ProductGrid from "@/components/product-grid"
import { Pagination } from "@/components/pagination"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export const metadata = {
  title: "Chandeliers | Caspian Lighting",
  description: "Explore our collection of elegant chandeliers for your home or commercial space",
}

export default async function ChandeliersPage({
  searchParams,
}: {
  searchParams: { [key: string]: string | string[] | undefined }
}) {
  // Get query parameters
  const page = typeof searchParams.page === "string" ? Number.parseInt(searchParams.page) : 1
  const limit = 9
  const sort = typeof searchParams.sort === "string" ? searchParams.sort : "latest"

  // Fetch category
  const category = await getCategoryBySlug("chandeliers")

  if (!category) {
    return (
      <div className="container py-12 md:py-16">
        <div className="text-center">
          <h1 className="text-3xl font-bold md:text-4xl">Chandeliers</h1>
          <p className="mt-4 text-muted-foreground">Category not found. Please check back later.</p>
        </div>
      </div>
    )
  }

  // Fetch products for this category
  const { products, totalProducts, totalPages } = await getProductsByCategory({
    categoryId: category.id,
    page,
    limit,
    sort,
    depth: 1,
  })

  return (
    <div className="container py-12 md:py-16">
      <div className="mb-12 text-center">
        <h1 className="text-3xl font-bold md:text-4xl">Chandeliers</h1>
        <p className="mt-4 max-w-3xl mx-auto text-muted-foreground">
          Elevate your space with our stunning collection of chandeliers. From classic crystal designs to modern
          minimalist pieces, our chandeliers combine artistry and functionality to create a captivating focal point in
          any room.
        </p>
      </div>

      {/* Featured Section */}
      <div className="mb-16 bg-amber-50 rounded-lg overflow-hidden">
        <div className="grid md:grid-cols-2 items-center">
          <div className="p-8 md:p-12">
            <h2 className="text-2xl font-bold mb-4">Illuminate with Elegance</h2>
            <p className="mb-6">
              Our chandeliers are more than just lighting fixtures—they're statement pieces that transform your space.
              Crafted with attention to detail and using premium materials, each chandelier is designed to create a
              perfect balance of light and beauty.
            </p>
            <Button className="bg-amber-600 hover:bg-amber-700">
              <a href="#products" className="flex items-center">
                Explore Collection <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
          </div>
          <div className="h-[400px] bg-amber-200">
            <img
              src="/placeholder.svg?height=400&width=600&text=Elegant+Chandeliers"
              alt="Elegant Chandeliers"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>

      {/* Chandelier Types */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-8 text-center">Chandelier Styles</h2>
        <div className="grid md:grid-cols-4 gap-6">
          {[
            {
              title: "Crystal",
              description: "Timeless elegance with sparkling crystal elements",
              image: "/placeholder.svg?height=300&width=300&text=Crystal",
            },
            {
              title: "Modern",
              description: "Sleek designs with clean lines and contemporary materials",
              image: "/placeholder.svg?height=300&width=300&text=Modern",
            },
            {
              title: "Traditional",
              description: "Classic designs inspired by historical periods",
              image: "/placeholder.svg?height=300&width=300&text=Traditional",
            },
            {
              title: "Industrial",
              description: "Raw, utilitarian aesthetic with metal finishes",
              image: "/placeholder.svg?height=300&width=300&text=Industrial",
            },
          ].map((style, index) => (
            <div key={index} className="text-center">
              <div className="rounded-full overflow-hidden w-40 h-40 mx-auto mb-4">
                <img src={style.image || "/placeholder.svg"} alt={style.title} className="w-full h-full object-cover" />
              </div>
              <h3 className="font-bold mb-2">{style.title}</h3>
              <p className="text-sm text-muted-foreground">{style.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Design Tips */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-8 text-center">Chandelier Design Tips</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="border rounded-lg p-6">
            <h3 className="font-bold mb-3">Sizing Your Chandelier</h3>
            <p className="text-muted-foreground">
              For dining rooms, choose a chandelier with a diameter (in inches) equal to the sum of the room's length
              and width in feet. Hang it 30-36 inches above the table for optimal effect.
            </p>
          </div>
          <div className="border rounded-lg p-6">
            <h3 className="font-bold mb-3">Placement Considerations</h3>
            <p className="text-muted-foreground">
              In entryways, ensure at least 7 feet of clearance below the chandelier. For two-story foyers, center the
              fixture where it can be viewed from above.
            </p>
          </div>
          <div className="border rounded-lg p-6">
            <h3 className="font-bold mb-3">Lighting Layers</h3>
            <p className="text-muted-foreground">
              Complement your chandelier with other lighting types like wall sconces or table lamps to create a balanced
              lighting scheme with multiple layers.
            </p>
          </div>
        </div>
      </div>

      {/* Products */}
      <div id="products" className="mb-16">
        <h2 className="text-2xl font-bold mb-8">Our Chandelier Collection</h2>

        {products.length > 0 ? (
          <>
            <div className="mb-8">
              <p className="text-sm text-muted-foreground">
                Showing {products.length} of {totalProducts} chandeliers
              </p>
            </div>

            <ProductGrid products={products} />

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="mt-8 flex justify-center">
                <Pagination totalPages={totalPages} currentPage={page} />
              </div>
            )}
          </>
        ) : (
          <div className="flex h-[400px] items-center justify-center rounded-md border border-dashed">
            <div className="text-center">
              <h3 className="text-lg font-medium">No products found</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                We're currently updating our collection. Please check back soon.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* FAQ */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-8 text-center">Frequently Asked Questions</h2>
        <div className="grid md:grid-cols-2 gap-6">
          {[
            {
              question: "How do I choose the right size chandelier?",
              answer:
                "For dining rooms, add the room's length and width in feet, then convert to inches for the ideal diameter. For other spaces, consider ceiling height and room dimensions.",
            },
            {
              question: "Can chandeliers be installed on sloped ceilings?",
              answer:
                "Yes, many chandeliers can be installed on sloped ceilings with special canopy adapters. Our installation team can assess your specific situation.",
            },
            {
              question: "Do you offer installation services?",
              answer:
                "Yes, we provide professional installation services for all our lighting products. Our certified technicians ensure safe and proper installation.",
            },
            {
              question: "How do I clean my crystal chandelier?",
              answer:
                "Turn off and allow the fixture to cool completely. Use a chandelier cleaning spray or a solution of mild dish soap and water. Avoid direct spraying; instead, apply to a lint-free cloth.",
            },
          ].map((faq, index) => (
            <div key={index} className="border rounded-lg p-6">
              <h3 className="font-bold mb-2">{faq.question}</h3>
              <p className="text-muted-foreground">{faq.answer}</p>
            </div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="bg-amber-600 text-white rounded-lg p-12 text-center">
        <h2 className="text-2xl font-bold mb-4">Need Help Choosing the Perfect Chandelier?</h2>
        <p className="max-w-2xl mx-auto mb-8">
          Our lighting experts are ready to assist you in finding the ideal chandelier for your space. Contact us for
          personalized recommendations and design advice.
        </p>
        <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/20">
          <a href="/contact">Contact Our Experts</a>
        </Button>
      </div>
    </div>
  )
}
