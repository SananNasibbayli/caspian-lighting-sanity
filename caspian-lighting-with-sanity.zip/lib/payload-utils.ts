import payload from "@/payload"

// Get global site data
export async function getGlobals() {
  try {
    const [navigation, footer, socialMedia, siteSettings] = await Promise.all([
      payload.findGlobal({ slug: "navigation" }),
      payload.findGlobal({ slug: "footer" }),
      payload.findGlobal({ slug: "social-media" }),
      payload.findGlobal({ slug: "site-settings" }),
    ])

    return {
      navigation,
      footer,
      socialMedia,
      siteSettings,
    }
  } catch (error) {
    console.error("Error fetching globals:", error)
    return {
      navigation: null,
      footer: null,
      socialMedia: null,
      siteSettings: null,
    }
  }
}

// Get products with pagination and filtering
export async function getProducts({
  page = 1,
  limit = 10,
  category,
  sort = "latest",
  search,
  depth = 0,
}: {
  page?: number
  limit?: number
  category?: string
  sort?: string
  search?: string
  depth?: number
}) {
  try {
    const where: any = {}

    // Add category filter
    if (category) {
      where.category = {
        equals: category,
      }
    }

    // Add search filter
    if (search) {
      where.or = [
        {
          title: {
            like: search,
          },
        },
        {
          description: {
            like: search,
          },
        },
      ]
    }

    // Determine sort order
    let sortOptions = {}

    switch (sort) {
      case "price-low":
        sortOptions = { price: 1 }
        break
      case "price-high":
        sortOptions = { price: -1 }
        break
      case "featured":
        where.featured = {
          equals: true,
        }
        sortOptions = { createdAt: -1 }
        break
      case "oldest":
        sortOptions = { createdAt: 1 }
        break
      case "latest":
      default:
        sortOptions = { createdAt: -1 }
        break
    }

    const productsQuery = await payload.find({
      collection: "products",
      where,
      sort: sortOptions,
      page,
      limit,
      depth,
    })

    return {
      products: productsQuery.docs,
      totalProducts: productsQuery.totalDocs,
      totalPages: productsQuery.totalPages,
      currentPage: productsQuery.page,
    }
  } catch (error) {
    console.error("Error fetching products:", error)
    return {
      products: [],
      totalProducts: 0,
      totalPages: 0,
      currentPage: 1,
    }
  }
}

// Get a single product by slug
export async function getProduct({ slug, depth = 2 }: { slug: string; depth?: number }) {
  try {
    const product = await payload.find({
      collection: "products",
      where: {
        slug: {
          equals: slug,
        },
      },
      depth,
      limit: 1,
    })

    if (!product.docs[0]) {
      return null
    }

    return product.docs[0]
  } catch (error) {
    console.error(`Error fetching product with slug ${slug}:`, error)
    return null
  }
}

// Get related products
export async function getRelatedProducts({
  category,
  currentProductId,
  limit = 4,
}: {
  category: string
  currentProductId: string
  limit?: number
}) {
  try {
    const relatedProducts = await payload.find({
      collection: "products",
      where: {
        and: [
          {
            category: {
              equals: category,
            },
          },
          {
            id: {
              not_equals: currentProductId,
            },
          },
        ],
      },
      limit,
      depth: 1,
    })

    return relatedProducts.docs
  } catch (error) {
    console.error("Error fetching related products:", error)
    return []
  }
}

// Get all product categories
export async function getCategories() {
  try {
    const categoriesQuery = await payload.find({
      collection: "categories",
      limit: 100,
    })

    return categoriesQuery.docs
  } catch (error) {
    console.error("Error fetching categories:", error)
    return []
  }
}

// Get a single category by slug
export async function getCategoryBySlug(slug: string) {
  try {
    const category = await payload.find({
      collection: "categories",
      where: {
        slug: {
          equals: slug,
        },
      },
      limit: 1,
    })

    if (!category.docs[0]) {
      return null
    }

    return category.docs[0]
  } catch (error) {
    console.error(`Error fetching category with slug ${slug}:`, error)
    return null
  }
}

// Get products by category
export async function getProductsByCategory({
  categoryId,
  page = 1,
  limit = 10,
  sort = "latest",
  depth = 0,
}: {
  categoryId: string
  page?: number
  limit?: number
  sort?: string
  depth?: number
}) {
  try {
    const where: any = {
      category: {
        equals: categoryId,
      },
    }

    // Determine sort order
    let sortOptions = {}

    switch (sort) {
      case "price-low":
        sortOptions = { price: 1 }
        break
      case "price-high":
        sortOptions = { price: -1 }
        break
      case "featured":
        where.featured = {
          equals: true,
        }
        sortOptions = { createdAt: -1 }
        break
      case "oldest":
        sortOptions = { createdAt: 1 }
        break
      case "latest":
      default:
        sortOptions = { createdAt: -1 }
        break
    }

    const productsQuery = await payload.find({
      collection: "products",
      where,
      sort: sortOptions,
      page,
      limit,
      depth,
    })

    return {
      products: productsQuery.docs,
      totalProducts: productsQuery.totalDocs,
      totalPages: productsQuery.totalPages,
      currentPage: productsQuery.page,
    }
  } catch (error) {
    console.error("Error fetching products by category:", error)
    return {
      products: [],
      totalProducts: 0,
      totalPages: 0,
      currentPage: 1,
    }
  }
}

// Get blog posts with pagination and filtering
export async function getBlogPosts({
  page = 1,
  limit = 10,
  category,
  depth = 0,
}: {
  page?: number
  limit?: number
  category?: string
  depth?: number
}) {
  try {
    const where: any = {
      status: {
        equals: "published",
      },
    }

    // Add category filter
    if (category) {
      where.categories = {
        contains: category,
      }
    }

    const postsQuery = await payload.find({
      collection: "blog-posts",
      where,
      sort: { publishedAt: -1 },
      page,
      limit,
      depth,
    })

    return {
      posts: postsQuery.docs,
      totalPosts: postsQuery.totalDocs,
      totalPages: postsQuery.totalPages,
      currentPage: postsQuery.page,
    }
  } catch (error) {
    console.error("Error fetching blog posts:", error)
    return {
      posts: [],
      totalPosts: 0,
      totalPages: 0,
      currentPage: 1,
    }
  }
}

// Get a single blog post by slug
export async function getBlogPost({ slug, depth = 2 }: { slug: string; depth?: number }) {
  try {
    const post = await payload.find({
      collection: "blog-posts",
      where: {
        and: [
          {
            slug: {
              equals: slug,
            },
          },
          {
            status: {
              equals: "published",
            },
          },
        ],
      },
      depth,
      limit: 1,
    })

    if (!post.docs[0]) {
      return null
    }

    return post.docs[0]
  } catch (error) {
    console.error(`Error fetching blog post with slug ${slug}:`, error)
    return null
  }
}

// Get related blog posts
export async function getRelatedPosts({
  currentPostId,
  categories,
  limit = 3,
}: {
  currentPostId: string
  categories: string[]
  limit?: number
}) {
  try {
    if (!categories.length) {
      return []
    }

    const relatedPosts = await payload.find({
      collection: "blog-posts",
      where: {
        and: [
          {
            id: {
              not_equals: currentPostId,
            },
          },
          {
            status: {
              equals: "published",
            },
          },
          {
            categories: {
              in: categories,
            },
          },
        ],
      },
      limit,
      depth: 1,
    })

    return relatedPosts.docs
  } catch (error) {
    console.error("Error fetching related posts:", error)
    return []
  }
}

// Get all blog categories
export async function getBlogCategories() {
  try {
    const categoriesQuery = await payload.find({
      collection: "blog-categories",
      limit: 100,
    })

    return categoriesQuery.docs
  } catch (error) {
    console.error("Error fetching blog categories:", error)
    return []
  }
}

// Get projects with pagination and filtering
export async function getProjects({
  page = 1,
  limit = 10,
  category,
  depth = 0,
}: {
  page?: number
  limit?: number
  category?: string
  depth?: number
}) {
  try {
    const where: any = {}

    // Add category filter
    if (category) {
      where.category = {
        equals: category,
      }
    }

    const projectsQuery = await payload.find({
      collection: "projects",
      where,
      sort: { completedAt: -1 },
      page,
      limit,
      depth,
    })

    return {
      projects: projectsQuery.docs,
      totalProjects: projectsQuery.totalDocs,
      totalPages: projectsQuery.totalPages,
      currentPage: projectsQuery.page,
    }
  } catch (error) {
    console.error("Error fetching projects:", error)
    return {
      projects: [],
      totalProjects: 0,
      totalPages: 0,
      currentPage: 1,
    }
  }
}

// Get a single project by slug
export async function getProject({ slug, depth = 2 }: { slug: string; depth?: number }) {
  try {
    const project = await payload.find({
      collection: "projects",
      where: {
        slug: {
          equals: slug,
        },
      },
      depth,
      limit: 1,
    })

    if (!project.docs[0]) {
      return null
    }

    return project.docs[0]
  } catch (error) {
    console.error(`Error fetching project with slug ${slug}:`, error)
    return null
  }
}

// Get all project categories
export async function getProjectCategories() {
  try {
    const categoriesQuery = await payload.find({
      collection: "project-categories",
      limit: 100,
    })

    return categoriesQuery.docs
  } catch (error) {
    console.error("Error fetching project categories:", error)
    return []
  }
}

// Get a single page by slug
export async function getPage({ slug, depth = 2 }: { slug: string; depth?: number }) {
  try {
    const page = await payload.find({
      collection: "pages",
      where: {
        slug: {
          equals: slug,
        },
      },
      depth,
      limit: 1,
    })

    if (!page.docs[0]) {
      return null
    }

    return page.docs[0]
  } catch (error) {
    console.error(`Error fetching page with slug ${slug}:`, error)
    return null
  }
}

// Get all pages
export async function getPages() {
  try {
    const pagesQuery = await payload.find({
      collection: "pages",
      limit: 100,
    })

    return pagesQuery.docs
  } catch (error) {
    console.error("Error fetching pages:", error)
    return []
  }
}

// Get testimonials
export async function getTestimonials({ limit = 3 }: { limit?: number }) {
  try {
    const testimonialsQuery = await payload.find({
      collection: "testimonials",
      limit,
      depth: 1,
    })

    return testimonialsQuery.docs
  } catch (error) {
    console.error("Error fetching testimonials:", error)
    return []
  }
}
