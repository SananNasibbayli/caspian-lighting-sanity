"use client"

import { useRouter, useSearchParams } from "next/navigation"
import { useState, useEffect } from "react"
import { ChevronDown, X } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Checkbox } from "@/components/ui/checkbox"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"

export default function ProductFilters({ categories }: { categories: any[] }) {
  const router = useRouter()
  const searchParams = useSearchParams()

  const [mounted, setMounted] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [selectedSort, setSelectedSort] = useState<string>("latest")

  // Initialize state from URL on mount
  useEffect(() => {
    setMounted(true)

    const category = searchParams.get("category")
    if (category) {
      setSelectedCategory(category)
    }

    const sort = searchParams.get("sort")
    if (sort) {
      setSelectedSort(sort)
    }
  }, [searchParams])

  // Apply filters
  const applyFilters = () => {
    const params = new URLSearchParams()

    if (selectedCategory) {
      params.set("category", selectedCategory)
    }

    if (selectedSort && selectedSort !== "latest") {
      params.set("sort", selectedSort)
    }

    const page = searchParams.get("page")
    if (page && page !== "1") {
      params.set("page", page)
    }

    const search = searchParams.get("search")
    if (search) {
      params.set("search", search)
    }

    router.push(`/products?${params.toString()}`)
  }

  // Reset filters
  const resetFilters = () => {
    setSelectedCategory(null)
    setSelectedSort("latest")
    router.push("/products")
  }

  // Handle category change
  const handleCategoryChange = (categoryId: string) => {
    setSelectedCategory(categoryId === selectedCategory ? null : categoryId)
  }

  // Handle sort change
  const handleSortChange = (sort: string) => {
    setSelectedSort(sort)
  }

  if (!mounted) {
    return <div className="h-[400px] rounded-md border border-dashed animate-pulse" />
  }

  return (
    <div>
      {/* Desktop Filters */}
      <div className="hidden md:block">
        <div className="sticky top-24 space-y-6">
          <div>
            <h3 className="mb-4 text-lg font-medium">Filters</h3>
            <Button variant="outline" size="sm" className="mb-4 flex items-center gap-1" onClick={resetFilters}>
              <X className="h-4 w-4" /> Reset Filters
            </Button>
          </div>

          <div>
            <h4 className="mb-2 text-sm font-medium">Sort By</h4>
            <div className="space-y-2">
              {[
                { value: "latest", label: "Latest" },
                { value: "price-low", label: "Price: Low to High" },
                { value: "price-high", label: "Price: High to Low" },
                { value: "featured", label: "Featured" },
              ].map((option) => (
                <div key={option.value} className="flex items-center gap-2">
                  <Checkbox
                    id={`sort-${option.value}`}
                    checked={selectedSort === option.value}
                    onCheckedChange={() => handleSortChange(option.value)}
                  />
                  <label htmlFor={`sort-${option.value}`} className="text-sm cursor-pointer">
                    {option.label}
                  </label>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          <Accordion type="single" collapsible defaultValue="categories">
            <AccordionItem value="categories" className="border-none">
              <AccordionTrigger className="py-2">
                <h4 className="text-sm font-medium">Categories</h4>
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-2 pt-1">
                  {categories.map((category) => (
                    <div key={category.id} className="flex items-center gap-2">
                      <Checkbox
                        id={`category-${category.id}`}
                        checked={selectedCategory === category.id}
                        onCheckedChange={() => handleCategoryChange(category.id)}
                      />
                      <label htmlFor={`category-${category.id}`} className="text-sm cursor-pointer">
                        {category.title}
                      </label>
                    </div>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>

          <Separator />

          <Button className="w-full bg-amber-600 hover:bg-amber-700" onClick={applyFilters}>
            Apply Filters
          </Button>
        </div>
      </div>

      {/* Mobile Filters */}
      <div className="mb-6 flex items-center justify-between md:hidden">
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              <span>Filters</span> <ChevronDown className="h-4 w-4" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left">
            <SheetHeader>
              <SheetTitle>Filters</SheetTitle>
            </SheetHeader>
            <div className="mt-6 space-y-6">
              <div>
                <Button variant="outline" size="sm" className="mb-4 flex items-center gap-1" onClick={resetFilters}>
                  <X className="h-4 w-4" /> Reset Filters
                </Button>
              </div>

              <div>
                <h4 className="mb-2 text-sm font-medium">Sort By</h4>
                <div className="space-y-2">
                  {[
                    { value: "latest", label: "Latest" },
                    { value: "price-low", label: "Price: Low to High" },
                    { value: "price-high", label: "Price: High to Low" },
                    { value: "featured", label: "Featured" },
                  ].map((option) => (
                    <div key={option.value} className="flex items-center gap-2">
                      <Checkbox
                        id={`mobile-sort-${option.value}`}
                        checked={selectedSort === option.value}
                        onCheckedChange={() => handleSortChange(option.value)}
                      />
                      <label htmlFor={`mobile-sort-${option.value}`} className="text-sm cursor-pointer">
                        {option.label}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              <Separator />

              <div>
                <h4 className="mb-2 text-sm font-medium">Categories</h4>
                <div className="space-y-2">
                  {categories.map((category) => (
                    <div key={category.id} className="flex items-center gap-2">
                      <Checkbox
                        id={`mobile-category-${category.id}`}
                        checked={selectedCategory === category.id}
                        onCheckedChange={() => handleCategoryChange(category.id)}
                      />
                      <label htmlFor={`mobile-category-${category.id}`} className="text-sm cursor-pointer">
                        {category.title}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              <Separator />

              <Button
                className="w-full bg-amber-600 hover:bg-amber-700"
                onClick={() => {
                  applyFilters()
                  document.body.click() // Close the sheet
                }}
              >
                Apply Filters
              </Button>
            </div>
          </SheetContent>
        </Sheet>

        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Sort:</span>
          <select
            className="rounded-md border border-input bg-background px-3 py-1 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            value={selectedSort}
            onChange={(e) => {
              handleSortChange(e.target.value)
              const params = new URLSearchParams(searchParams.toString())
              if (e.target.value !== "latest") {
                params.set("sort", e.target.value)
              } else {
                params.delete("sort")
              }
              router.push(`/products?${params.toString()}`)
            }}
          >
            <option value="latest">Latest</option>
            <option value="price-low">Price: Low to High</option>
            <option value="price-high">Price: High to Low</option>
            <option value="featured">Featured</option>
          </select>
        </div>
      </div>
    </div>
  )
}
