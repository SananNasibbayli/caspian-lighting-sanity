import { getProductsByCategory } from "@/lib/payload-utils"
import { getCategoryBySlug } from "@/lib/payload-utils"
import ProductGrid from "@/components/product-grid"
import { Pagination } from "@/components/pagination"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export const metadata = {
  title: "Outdoor Lights | Caspian Lighting",
  description: "Find the perfect outdoor lighting solutions for your garden, patio, or exterior spaces",
}

export default async function OutdoorLightsPage({
  searchParams,
}: {
  searchParams: { [key: string]: string | string[] | undefined }
}) {
  // Get query parameters
  const page = typeof searchParams.page === "string" ? Number.parseInt(searchParams.page) : 1
  const limit = 9
  const sort = typeof searchParams.sort === "string" ? searchParams.sort : "latest"

  // Fetch category
  const category = await getCategoryBySlug("outdoor-lights")

  if (!category) {
    return (
      <div className="container py-12 md:py-16">
        <div className="text-center">
          <h1 className="text-3xl font-bold md:text-4xl">Outdoor Lights</h1>
          <p className="mt-4 text-muted-foreground">Category not found. Please check back later.</p>
        </div>
      </div>
    )
  }

  // Fetch products for this category
  const { products, totalProducts, totalPages } = await getProductsByCategory({
    categoryId: category.id,
    page,
    limit,
    sort,
    depth: 1,
  })

  return (
    <div className="container py-12 md:py-16">
      <div className="mb-12 text-center">
        <h1 className="text-3xl font-bold md:text-4xl">Outdoor Lights</h1>
        <p className="mt-4 max-w-3xl mx-auto text-muted-foreground">
          Extend your living space into the outdoors with our weather-resistant lighting collection. From pathway lights
          to wall lanterns, our outdoor lighting solutions combine durability, efficiency, and style to enhance your
          exterior spaces.
        </p>
      </div>

      {/* Featured Section */}
      <div className="mb-16 bg-amber-50 rounded-lg overflow-hidden">
        <div className="grid md:grid-cols-2 items-center">
          <div className="p-8 md:p-12">
            <h2 className="text-2xl font-bold mb-4">Illuminate Your Outdoors</h2>
            <p className="mb-6">
              Our outdoor lighting collection is designed to withstand the elements while providing beautiful
              illumination for your exterior spaces. From enhancing security to creating ambiance for outdoor
              entertaining, our fixtures combine functionality with aesthetic appeal.
            </p>
            <Button className="bg-amber-600 hover:bg-amber-700">
              <a href="#products" className="flex items-center">
                Explore Collection <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
          </div>
          <div className="h-[400px] bg-amber-200">
            <img
              src="/placeholder.svg?height=400&width=600&text=Outdoor+Lighting"
              alt="Outdoor Lighting Collection"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>

      {/* Outdoor Light Types */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-8 text-center">Outdoor Lighting Categories</h2>
        <div className="grid md:grid-cols-4 gap-6">
          {[
            {
              title: "Wall Lanterns",
              description: "Mounted fixtures for entryways, garages, and exterior walls",
              image: "/placeholder.svg?height=300&width=300&text=Wall+Lanterns",
            },
            {
              title: "Path Lights",
              description: "Ground-level fixtures to illuminate walkways and garden paths",
              image: "/placeholder.svg?height=300&width=300&text=Path+Lights",
            },
            {
              title: "Flood Lights",
              description: "Powerful fixtures for security and large area illumination",
              image: "/placeholder.svg?height=300&width=300&text=Flood+Lights",
            },
            {
              title: "Deck & Patio Lights",
              description: "Specialized fixtures for outdoor living spaces",
              image: "/placeholder.svg?height=300&width=300&text=Deck+Lights",
            },
          ].map((type, index) => (
            <div key={index} className="text-center">
              <div className="rounded-full overflow-hidden w-40 h-40 mx-auto mb-4">
                <img src={type.image || "/placeholder.svg"} alt={type.title} className="w-full h-full object-cover" />
              </div>
              <h3 className="font-bold mb-2">{type.title}</h3>
              <p className="text-sm text-muted-foreground">{type.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Outdoor Lighting Guide */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-8 text-center">Outdoor Lighting Guide</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="border rounded-lg p-6">
            <h3 className="font-bold mb-3">IP Ratings Explained</h3>
            <p className="text-muted-foreground">
              IP (Ingress Protection) ratings indicate water and dust resistance. For outdoor use, look for IP44 or
              higher. IP65 is suitable for most outdoor applications, while IP67 or IP68 is recommended for areas with
              direct water exposure.
            </p>
          </div>
          <div className="border rounded-lg p-6">
            <h3 className="font-bold mb-3">Energy Efficiency</h3>
            <p className="text-muted-foreground">
              Our outdoor lighting collection features energy-efficient LED technology, reducing electricity consumption
              while providing bright, reliable illumination with minimal maintenance requirements.
            </p>
          </div>
          <div className="border rounded-lg p-6">
            <h3 className="font-bold mb-3">Smart Outdoor Lighting</h3>
            <p className="text-muted-foreground">
              Many of our outdoor fixtures are compatible with smart home systems, allowing you to control lighting
              remotely, set schedules, and integrate with motion sensors for enhanced security.
            </p>
          </div>
        </div>
      </div>

      {/* Products */}
      <div id="products" className="mb-16">
        <h2 className="text-2xl font-bold mb-8">Our Outdoor Lighting Collection</h2>

        {products.length > 0 ? (
          <>
            <div className="mb-8">
              <p className="text-sm text-muted-foreground">
                Showing {products.length} of {totalProducts} outdoor lights
              </p>
            </div>

            <ProductGrid products={products} />

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="mt-8 flex justify-center">
                <Pagination totalPages={totalPages} currentPage={page} />
              </div>
            )}
          </>
        ) : (
          <div className="flex h-[400px] items-center justify-center rounded-md border border-dashed">
            <div className="text-center">
              <h3 className="text-lg font-medium">No products found</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                We're currently updating our collection. Please check back soon.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Landscape Lighting Ideas */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-8 text-center">Landscape Lighting Ideas</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              idea: "Garden Illumination",
              description: "Highlight plants, flowers, and garden features with strategically placed lights",
              image: "/placeholder.svg?height=300&width=300&text=Garden",
            },
            {
              idea: "Architectural Accents",
              description: "Use uplighting to emphasize the architectural features of your home's exterior",
              image: "/placeholder.svg?height=300&width=300&text=Architecture",
            },
            {
              idea: "Water Feature Lighting",
              description: "Enhance ponds, fountains, and pools with underwater or perimeter lighting",
              image: "/placeholder.svg?height=300&width=300&text=Water",
            },
            {
              idea: "Entertainment Areas",
              description: "Create ambiance in outdoor dining and seating areas with string lights or lanterns",
              image: "/placeholder.svg?height=300&width=300&text=Entertainment",
            },
          ].map((idea, index) => (
            <div key={index} className="border rounded-lg overflow-hidden">
              <div className="h-48">
                <img src={idea.image || "/placeholder.svg"} alt={idea.idea} className="w-full h-full object-cover" />
              </div>
              <div className="p-4">
                <h3 className="font-bold mb-2">{idea.idea}</h3>
                <p className="text-sm text-muted-foreground">{idea.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="bg-amber-600 text-white rounded-lg p-12 text-center">
        <h2 className="text-2xl font-bold mb-4">Transform Your Outdoor Space</h2>
        <p className="max-w-2xl mx-auto mb-8">
          Our lighting experts can help you create a custom outdoor lighting plan that enhances the beauty, safety, and
          functionality of your exterior spaces.
        </p>
        <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/20">
          <a href="/contact">Request a Consultation</a>
        </Button>
      </div>
    </div>
  )
}
