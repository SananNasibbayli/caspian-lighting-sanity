import Link from "next/link"
import Image from "next/image"
import { formatPrice } from "@/lib/utils"

type RelatedProductsProps = {
  products: any[]
}

export default function RelatedProducts({ products }: RelatedProductsProps) {
  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-4">
      {products.map((product) => (
        <div
          key={product.id}
          className="group flex flex-col overflow-hidden rounded-lg border bg-white shadow-sm transition-all hover:shadow-md"
        >
          <Link href={`/products/${product.slug}`} className="aspect-square overflow-hidden bg-gray-100">
            <Image
              src={product.images?.[0]?.image?.url || "/placeholder.svg?height=300&width=300"}
              alt={product.images?.[0]?.alt || product.title}
              width={300}
              height={300}
              className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
          </Link>
          <div className="flex flex-1 flex-col p-4">
            <Link href={`/products/${product.slug}`} className="flex-1">
              <h3 className="line-clamp-2 font-medium hover:text-amber-600">{product.title}</h3>
            </Link>
            <div className="mt-2">
              <p className="font-medium text-amber-600">{formatPrice(product.price)}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
