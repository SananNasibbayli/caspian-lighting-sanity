import { notFound } from "next/navigation"
import Image from "next/image"
import { format } from "date-fns"
import { getBlogPost } from "@/lib/payload-utils"
import { getRelatedPosts } from "@/lib/payload-utils"
import { RichText } from "@/components/rich-text"
import BlogPostCard from "@/components/blog-post-card"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"

export async function generateMetadata({ params }: { params: { slug: string } }) {
  const post = await getBlogPost({ slug: params.slug })

  if (!post) {
    return {
      title: "Blog Post Not Found",
      description: "The requested blog post could not be found",
    }
  }

  return {
    title: `${post.title} | Caspian Lighting Blog`,
    description: post.excerpt,
    openGraph: {
      images: [{ url: post.coverImage?.url || "" }],
    },
  }
}

export default async function BlogPostPage({ params }: { params: { slug: string } }) {
  const post = await getBlogPost({ slug: params.slug })

  if (!post) {
    notFound()
  }

  const relatedPosts = await getRelatedPosts({
    currentPostId: post.id,
    categories: post.categories.map((cat) => cat.id),
    limit: 3,
  })

  return (
    <div className="container py-12 md:py-16">
      <Breadcrumb className="mb-8">
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink href="/">Home</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink href="/blog">Blog</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink href={`/blog/${post.slug}`} isCurrentPage>
              {post.title}
            </BreadcrumbLink>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>

      <article className="mx-auto max-w-3xl">
        <header className="mb-8 text-center">
          <div className="mb-4 flex items-center justify-center gap-2">
            {post.categories.map((category) => (
              <a
                key={category.id}
                href={`/blog/categories/${category.slug}`}
                className="rounded-full bg-amber-100 px-3 py-1 text-sm text-amber-800 hover:bg-amber-200"
              >
                {category.title}
              </a>
            ))}
          </div>

          <h1 className="text-3xl font-bold md:text-4xl lg:text-5xl">{post.title}</h1>

          <div className="mt-4 flex items-center justify-center gap-4">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 overflow-hidden rounded-full bg-amber-100">
                {post.author.image ? (
                  <Image
                    src={post.author.image.url || "/placeholder.svg"}
                    alt={post.author.name}
                    width={32}
                    height={32}
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <div className="flex h-full w-full items-center justify-center text-xs font-medium text-amber-800">
                    {post.author.name.charAt(0)}
                  </div>
                )}
              </div>
              <span className="text-sm">{post.author.name}</span>
            </div>

            <span className="text-sm text-muted-foreground">{format(new Date(post.publishedAt), "MMMM d, yyyy")}</span>
          </div>
        </header>

        {post.coverImage && (
          <div className="mb-8 overflow-hidden rounded-lg">
            <Image
              src={post.coverImage.url || "/placeholder.svg"}
              alt={post.title}
              width={1200}
              height={630}
              className="h-auto w-full object-cover"
            />
          </div>
        )}

        <div className="prose max-w-none">
          <RichText content={post.content} />
        </div>
      </article>

      {/* Related Posts */}
      {relatedPosts.length > 0 && (
        <div className="mt-20">
          <h2 className="mb-8 text-2xl font-bold text-center">Related Articles</h2>
          <div className="grid gap-6 md:grid-cols-3">
            {relatedPosts.map((post) => (
              <BlogPostCard key={post.id} post={post} />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
