"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Menu, ShoppingCart } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useCart } from "@/lib/cart-context"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

// Update the categories array to include the correct slugs
const categories = [
  { title: "Chandeliers", slug: "chandeliers" },
  { title: "Wall Lights", slug: "wall-lights" },
  { title: "Spotlights", slug: "spotlights" },
  { title: "Outdoor Lights", slug: "outdoor-lights" },
  { title: "Smart Lighting", slug: "smart-lighting" },
]

const defaultNavigation = [
  { title: "Home", href: "/" },
  { title: "Products", href: "/products" },
  { title: "Projects", href: "/projects" },
  { title: "Blog", href: "/blog" },
  { title: "About", href: "/about" },
  { title: "Contact", href: "/contact" },
]

export default function SiteHeader({ navigation = defaultNavigation }) {
  const pathname = usePathname()
  const [isScrolled, setIsScrolled] = useState(false)
  const { cartItems } = useCart()

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header
      className={`sticky top-0 z-40 w-full transition-all duration-200 ${
        isScrolled
          ? "border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60"
          : "bg-transparent"
      }`}
    >
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-6 md:gap-10">
          <Link href="/" className="flex items-center space-x-2">
            <span className="text-xl font-bold tracking-tight text-amber-600">Caspian Lighting</span>
          </Link>
          <nav className="hidden gap-6 md:flex">
            <Link
              href="/"
              className={`text-sm font-medium transition-colors hover:text-amber-600 ${
                pathname === "/" ? "text-amber-600" : "text-foreground"
              }`}
            >
              Home
            </Link>

            {/* Products Dropdown */}
            {/* Update the dropdown menu items to link to our new pages */}
            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center gap-1 text-sm font-medium transition-colors hover:text-amber-600">
                Products
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start">
                <DropdownMenuItem asChild>
                  <Link href="/products">All Products</Link>
                </DropdownMenuItem>
                {categories.map((category) => (
                  <DropdownMenuItem key={category.slug} asChild>
                    <Link href={`/${category.slug}`}>{category.title}</Link>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <Link
              href="/projects"
              className={`text-sm font-medium transition-colors hover:text-amber-600 ${
                pathname === "/projects" ? "text-amber-600" : "text-foreground"
              }`}
            >
              Projects
            </Link>
            <Link
              href="/blog"
              className={`text-sm font-medium transition-colors hover:text-amber-600 ${
                pathname === "/blog" ? "text-amber-600" : "text-foreground"
              }`}
            >
              Blog
            </Link>
            <Link
              href="/about"
              className={`text-sm font-medium transition-colors hover:text-amber-600 ${
                pathname === "/about" ? "text-amber-600" : "text-foreground"
              }`}
            >
              About
            </Link>
            <Link
              href="/contact"
              className={`text-sm font-medium transition-colors hover:text-amber-600 ${
                pathname === "/contact" ? "text-amber-600" : "text-foreground"
              }`}
            >
              Contact
            </Link>
          </nav>
        </div>
        <div className="flex items-center gap-4">
          <Link href="/cart" className="relative">
            <ShoppingCart className="h-5 w-5" />
            {cartItems.length > 0 && (
              <span className="absolute -right-2 -top-2 flex h-5 w-5 items-center justify-center rounded-full bg-amber-600 text-xs text-white">
                {cartItems.length}
              </span>
            )}
            <span className="sr-only">Cart</span>
          </Link>
          <Button variant="outline" className="hidden md:flex">
            <Link href="/contact">Contact Us</Link>
          </Button>
          <Button className="hidden bg-amber-600 hover:bg-amber-700 md:flex">
            <Link href="/products">Explore Collections</Link>
          </Button>

          {/* Mobile Menu */}
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <div className="flex flex-col space-y-4 pt-6">
                <Link
                  href="/"
                  className={`text-sm font-medium transition-colors hover:text-amber-600 ${
                    pathname === "/" ? "text-amber-600" : "text-foreground"
                  }`}
                >
                  Home
                </Link>
                {/* Update the mobile menu to link to our new pages */}
                <div className="space-y-3">
                  <p className="text-sm font-medium">Products</p>
                  <div className="ml-4 flex flex-col space-y-2">
                    <Link
                      href="/products"
                      className="text-sm text-muted-foreground transition-colors hover:text-amber-600"
                    >
                      All Products
                    </Link>
                    {categories.map((category) => (
                      <Link
                        key={category.slug}
                        href={`/${category.slug}`}
                        className="text-sm text-muted-foreground transition-colors hover:text-amber-600"
                      >
                        {category.title}
                      </Link>
                    ))}
                  </div>
                </div>
                <Link
                  href="/projects"
                  className={`text-sm font-medium transition-colors hover:text-amber-600 ${
                    pathname === "/projects" ? "text-amber-600" : "text-foreground"
                  }`}
                >
                  Projects
                </Link>
                <Link
                  href="/blog"
                  className={`text-sm font-medium transition-colors hover:text-amber-600 ${
                    pathname === "/blog" ? "text-amber-600" : "text-foreground"
                  }`}
                >
                  Blog
                </Link>
                <Link
                  href="/about"
                  className={`text-sm font-medium transition-colors hover:text-amber-600 ${
                    pathname === "/about" ? "text-amber-600" : "text-foreground"
                  }`}
                >
                  About
                </Link>
                <Link
                  href="/contact"
                  className={`text-sm font-medium transition-colors hover:text-amber-600 ${
                    pathname === "/contact" ? "text-amber-600" : "text-foreground"
                  }`}
                >
                  Contact
                </Link>
                <div className="pt-4">
                  <Button className="w-full bg-amber-600 hover:bg-amber-700">
                    <Link href="/contact">Contact Us</Link>
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}
