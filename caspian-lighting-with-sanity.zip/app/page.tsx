import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="flex min-h-screen w-full flex-col">
      {/* Navigation */}
      <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-6 md:gap-10">
            <Link href="/" className="flex items-center space-x-2">
              <span className="text-xl font-bold tracking-tight text-amber-600">Caspian Lighting</span>
            </Link>
            <nav className="hidden gap-6 md:flex">
              <Link href="#" className="text-sm font-medium transition-colors hover:text-amber-600">
                Chandeliers
              </Link>
              <Link href="#" className="text-sm font-medium transition-colors hover:text-amber-600">
                Wall Lights
              </Link>
              <Link href="#" className="text-sm font-medium transition-colors hover:text-amber-600">
                Spotlights
              </Link>
              <Link href="#" className="text-sm font-medium transition-colors hover:text-amber-600">
                Outdoor Lights
              </Link>
              <Link href="#" className="text-sm font-medium transition-colors hover:text-amber-600">
                Projects
              </Link>
            </nav>
          </div>
          <div className="flex items-center gap-4">
            <Link
              href="/admin"
              className="text-sm font-medium text-muted-foreground transition-colors hover:text-amber-600"
            >
              Admin
            </Link>
            <Button variant="outline" className="hidden md:flex">
              Contact Us
            </Button>
            <Button className="bg-amber-600 hover:bg-amber-700">Explore Collections</Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative h-[80vh] w-full overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-black/50 to-transparent">
            <div className="container relative flex h-full flex-col items-start justify-center gap-4 pt-16">
              <div className="animate-fade-in-up space-y-4 max-w-xl">
                <h1 className="text-4xl font-bold tracking-tighter text-white sm:text-5xl md:text-6xl lg:text-7xl">
                  Light Up Your World with Elegance
                </h1>
                <p className="text-xl text-white/90 md:text-2xl">
                  Premium lighting solutions for homes, offices, and design projects
                </p>
                <div className="flex flex-col gap-4 sm:flex-row">
                  <Button size="lg" className="bg-amber-600 hover:bg-amber-700">
                    <Link href="/products" className="flex items-center">
                      Explore Collections
                    </Link>
                  </Button>
                  <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/20">
                    View Projects
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Product Highlights */}
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container space-y-12 px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-amber-100 px-3 py-1 text-sm text-amber-800">
                  Our Collections
                </div>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Illuminate Every Space</h2>
                <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Discover our premium lighting solutions for every room and purpose
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {Array.from({ length: 4 }).map((_, i) => (
                <div
                  key={i}
                  className="group relative overflow-hidden rounded-lg shadow-lg transition-all hover:shadow-xl"
                >
                  <div className="h-80 w-full bg-amber-100"></div>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent opacity-80">
                    <div className="absolute bottom-0 w-full p-6">
                      <h3 className="text-xl font-bold text-white">Product {i + 1}</h3>
                      <p className="mb-4 text-white/80">A premium lighting solution for your space</p>
                      <Button variant="outline" className="border-white text-white hover:bg-white/20">
                        <Link href={`/products/product-${i + 1}`}>View Details</Link>
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Why Choose Caspian Lighting */}
        <section className="w-full bg-amber-50 py-12 md:py-24 lg:py-32">
          <div className="container space-y-12 px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-amber-100 px-3 py-1 text-sm text-amber-800">
                  Our Advantages
                </div>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  Why Choose Caspian Lighting?
                </h2>
                <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  We combine quality, customization, and reliability to deliver exceptional lighting solutions
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
              {[
                {
                  title: "Certified Quality",
                  description:
                    "All our products meet international quality standards and come with extended warranties",
                  icon: "Award",
                },
                {
                  title: "Project-Based Customization",
                  description:
                    "Our team works with you to create custom lighting solutions tailored to your specific needs",
                  icon: "Clock",
                },
                {
                  title: "Fast Delivery",
                  description: "Quick and reliable delivery service with professional installation options available",
                  icon: "Truck",
                },
              ].map((feature, index) => (
                <div
                  key={index}
                  className="flex flex-col items-center space-y-4 rounded-lg border bg-white p-6 shadow-sm transition-all hover:shadow-md"
                >
                  <div className="rounded-full bg-amber-100 p-4">
                    <div className="h-8 w-8 text-amber-600"></div>
                  </div>
                  <h3 className="text-xl font-bold">{feature.title}</h3>
                  <p className="text-center text-muted-foreground">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Newsletter */}
        <section className="w-full bg-amber-50 py-12 md:py-24 lg:py-32">
          <div className="container grid items-center gap-6 px-4 text-center md:px-6">
            <div className="space-y-3">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight">
                Stay Updated with Caspian Lighting
              </h2>
              <p className="mx-auto max-w-[600px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Subscribe to our newsletter for the latest product updates, design inspiration, and exclusive offers
              </p>
            </div>
            <div className="mx-auto w-full max-w-sm space-y-2">
              <form className="flex flex-col gap-2 sm:flex-row">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="h-10 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 flex-1"
                  required
                />
                <Button type="submit" className="bg-amber-600 hover:bg-amber-700">
                  Subscribe
                </Button>
              </form>
              <p className="text-xs text-muted-foreground">We respect your privacy. Unsubscribe at any time.</p>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="w-full border-t bg-white py-6 md:py-12">
        <div className="container grid gap-8 px-4 md:grid-cols-2 md:px-6 lg:grid-cols-4">
          <div className="space-y-4">
            <Link href="/" className="flex items-center space-x-2">
              <span className="text-xl font-bold tracking-tight text-amber-600">Caspian Lighting</span>
            </Link>
            <p className="text-sm text-muted-foreground">
              Premium lighting solutions for homes, offices, and design projects since 2005.
            </p>
            <div className="flex space-x-4">
              <Link href="#" className="text-muted-foreground hover:text-amber-600">
                <span className="sr-only">Facebook</span>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-amber-600">
                <span className="sr-only">Instagram</span>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-amber-600">
                <span className="sr-only">Twitter</span>
              </Link>
            </div>
          </div>
          <div className="space-y-4">
            <h3 className="text-sm font-medium">Collections</h3>
            <nav className="flex flex-col space-y-2 text-sm">
              <Link href="#" className="text-muted-foreground hover:text-amber-600">
                Chandeliers
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-amber-600">
                Wall Lights
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-amber-600">
                Spotlights
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-amber-600">
                Outdoor Lights
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-amber-600">
                Smart Lighting
              </Link>
            </nav>
          </div>
          <div className="space-y-4">
            <h3 className="text-sm font-medium">Company</h3>
            <nav className="flex flex-col space-y-2 text-sm">
              <Link href="#" className="text-muted-foreground hover:text-amber-600">
                About Us
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-amber-600">
                Projects
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-amber-600">
                Blog
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-amber-600">
                Careers
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-amber-600">
                Contact
              </Link>
            </nav>
          </div>
          <div className="space-y-4">
            <h3 className="text-sm font-medium">Contact Information</h3>
            <div className="flex flex-col space-y-2 text-sm text-muted-foreground">
              <p>123 Lighting Avenue, Baku, Azerbaijan</p>
              <p>Opening Hours: Mon-Fri 9:00 - 18:00</p>
              <p>Email: info@caspianlighting.az</p>
              <p>Phone: +994 12 345 6789</p>
            </div>
          </div>
        </div>
        <div className="container mt-8 border-t pt-6">
          <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
            <p className="text-xs text-muted-foreground">
              &copy; {new Date().getFullYear()} Caspian Lighting. All rights reserved.
            </p>
            <nav className="flex gap-4 text-xs">
              <Link href="#" className="text-muted-foreground hover:text-amber-600">
                Terms of Service
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-amber-600">
                Privacy Policy
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-amber-600">
                Cookie Policy
              </Link>
            </nav>
          </div>
        </div>
      </footer>
    </div>
  )
}
